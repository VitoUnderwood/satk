# count-line

## Usage
A cross-platform command line tool to do sentiment analysis task

## Installation
You can install, upgrade, uninstall SATK with these commands(without $):
```
$ pip install count-line
$ pip install --upgrade count-line
$ pip unstall count-line
```
