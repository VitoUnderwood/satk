import torch
import torch.nn as nn 

from specific.example import opinion_tagset

# from .modeling_bert import BertModel
from .crf import CRF
from transformers.modeling_bert import BertPreTrainedModel
from transformers.modeling_bert import BertModel


class TokenClassification(BertPreTrainedModel):
    def __init__(self, config, mode):
        super().__init__(config)
        self.bert = BertModel(config)
        self.mode = mode

        if 'gate' in mode:
            self.gate = nn.Sequential(
                nn.Linear(config.hidden_size*2, config.hidden_size),
                nn.ReLU()
            )

        self.crf = CRF(
            config.hidden_size, opinion_tagset.size(), opinion_tagset['SOS'],
            opinion_tagset['PAD'], dropout_prob=config.hidden_dropout_prob)

        self.init_weights()

    def inf_select(self, sequence_output, attention_mask, token_type_ids):
        # 1 1 1 1 1 1 0 0 0 
        # 0 0 0 0 1 1 0 0 0
        target_mask = attention_mask * token_type_ids
        # [B, H]
        h_target = torch.max(target_mask.unsqueeze(-1) * sequence_output, dim=1)[0]
        h_target = h_target.unsqueeze(1)
        L = sequence_output.size(1)

        gate = self.gate(torch.cat((sequence_output, h_target.repeat(1, L, 1)), dim=-1))
        # gate = self.gate(h_target)

        return gate * sequence_output

    def forward(self, input_ids, attention_mask, token_type_ids, labels):
        """
        input_ids, attention_mask, token_type_ids, labels: [B, L]
        """
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )

        sequence_output = outputs[0]
        if 'gate' in self.mode:
            sequence_output = self.inf_select(sequence_output, attention_mask, token_type_ids)

        attention_mask = attention_mask - token_type_ids
        attention_mask = attention_mask.type(torch.bool)
        loss, y_preds = self.crf(sequence_output, labels, attention_mask)
        
        return loss, y_preds
        
    # def output_emission(self, input_ids, attention_mask, token_type_ids):
    #     outputs = self.bert(
    #         input_ids=input_ids,
    #         attention_mask=attention_mask,
    #         token_type_ids=token_type_ids,
    #     )

    #     sequence_output = outputs[0]
    #     emission = self.crf.hidden2tag(outputs[0])
        
    #     attention_mask = attention_mask.type(torch.bool)
    #     y_preds = self.crf.predict(sequence_output, attention_mask)

    #     return emission, y_preds
