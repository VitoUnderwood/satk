import torch
import torch.nn as nn
import torch.nn.functional as F

import math

from specific.example import target_tagset

from .layers import AttentionMerge
from .modeling_bert import BertModel
from transformers.modeling_bert import BertPreTrainedModel


class AscoModel(BertPreTrainedModel):
    def __init__(self, config, mode='asc'):
        super().__init__(config)
        assert mode in ('asc', 'asco', 'bert-pair', 'bert-segment')

        self.mode = mode
        config.output_attentions = True

        print(f'absa: {mode}')

        self.bert = BertModel(config)

        self.classifier = nn.Sequential(
            # nn.Linear(config.hidden_size, config.hidden_size),
            # nn.Tanh(),
            nn.Dropout(config.hidden_dropout_prob),
            nn.Linear(config.hidden_size, 3),
        )

        self.init_weights()

    # def one_hot(self, labels, tagset):        
    #     batch_size, length = labels.size()  # (B, L)
    #     emission = torch.zeros(batch_size, length, tagset.size()).to(labels.device).scatter_(
    #         dim=2, index=labels.unsqueeze(-1), src=torch.tensor(1.),
    #     )
    #     return emission

    def is_target(self, target_labels):
        B_target = (target_labels == target_tagset['B-target'])
        I_target = (target_labels == target_tagset['I-target'])
        is_target = (B_target + I_target).type(torch.float)
        return is_target

    def forward(self, input_ids, attention_mask, token_type_ids,
                target_labels, entity_labels, polarity_labels):
        """
        input_ids, attention_mask, token_type_ids: [B, L]
        labels: [B,]
        """
        is_target = self.is_target(target_labels)

        return self._forward(input_ids, attention_mask, token_type_ids, polarity_labels,
                             entity_labels, is_target)

    def _forward(self, input_ids, attention_mask, token_type_ids,
                 polarity_labels, entity_labels, is_target):

        bert_inputs = {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'token_type_ids': token_type_ids,
        }

        if self.mode == 'asco':
            bert_inputs['entity_labels'] = entity_labels

        # asc, bert-pair, bert-segment

        bert_output = self.bert(**bert_inputs)

        sequence_output = bert_output[0]
        attentions = bert_output[2]

        # [B, H]
        h = torch.max(is_target.unsqueeze(-1) * sequence_output, dim=1)[0]
        # h = torch.max((1-is_target).unsqueeze(-1) * -1e4 + sequence_output, dim=1)[0]

        logits = self.classifier(h)
        loss = F.cross_entropy(logits, polarity_labels)

        return loss, logits, attentions
