import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from transformers.modeling_bert import BertSelfAttention, BertSelfOutput, BertIntermediate, BertOutput


class AttentionMerge(nn.Module):
    """
    H (B, L, hidden_size) => h (B, hidden_size)
    """
    def __init__(self, input_size, attention_size, dropout_prob):
        super(AttentionMerge, self).__init__()
        self.attention_size = attention_size
        self.hidden_layer = nn.Linear(input_size, self.attention_size)
        self.query_ = nn.Parameter(torch.Tensor(self.attention_size, 1))
        self.dropout = nn.Dropout(dropout_prob)

        self.query_.data.normal_(mean=0.0, std=0.02)
        # self.query_.data.normal_(mean=0.0, std=0.01)
        # self.query_.data.uniform_(-0.01, 0.01)

    def forward(self, values, mask=None, add_inf=None):
        """
        (b, l, h) -> (b, h)
        """
        keys = self.hidden_layer(values)
        keys = torch.tanh(keys)

        query_var = torch.var(self.query_)

        # (b, l, h) + (h, 1) -> (b, l, 1)
        """
        不妨令 E(self.query_) = E(keys_i) = 0 以及独立，可得 D(self.query_ * keys_i) = D(self.query_)D(keys_i)
        而 D(keys @ self.query_) = attention_size * D(self.query_) * D(keys_i)
        
        为了保证 score = D(keys @ self.query_) 的方差与keys_i一致，因此取
        score = D(keys @ self.query_) / sqrt(attention_size * D(self.query_))
        
        这样的话，D(score) = D(keys @ self.query_) / [sqrt(attention_size * D(self.query_))] ^ 2 = D(self.keys_i)
        
        虽然不知道为什么要保证D(score) = D(self.keys_i)，但是scaled dot-product attention中sclaed的目的就是让方差保持一致，实际效果也比较好
        """
        attention_probs = keys @ self.query_ / math.sqrt(self.attention_size * query_var)
        
        if mask is not None:
            mask = (1 - mask.unsqueeze(-1).type(torch.float)) * -10000.
            attention_probs += mask
        
        if add_inf is not None:
            attention_probs += add_inf.unsqueeze(-1)
            
        attention_probs = F.softmax(attention_probs, dim=1)
        attention_probs = self.dropout(attention_probs)

        context = torch.sum(attention_probs*values, dim=1)
        return context, attention_probs
        

class IMNSelfAttention(BertSelfAttention):
    def __init__(self, config):
        super().__init__(config)
        self.layer_norm_eps = config.layer_norm_eps
    
    def forward(self, hidden_states, opinion_transmission, attention_mask):

        mixed_query_layer = self.query(hidden_states)

        mixed_key_layer = self.key(hidden_states)
        mixed_value_layer = self.value(hidden_states)

        query_layer = self.transpose_for_scores(mixed_query_layer)
        key_layer = self.transpose_for_scores(mixed_key_layer)
        value_layer = self.transpose_for_scores(mixed_value_layer)

        # Take the dot product between "query" and "key" to get the raw attention scores.
        attention_scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))
        attention_scores = attention_scores / math.sqrt(self.attention_head_size)
        
        seq_length = hidden_states.size(-2)
        distance_matrix = [[1/(i-j+self.layer_norm_eps)*(i!=j) for i in range(seq_length)] for j in range(seq_length)]
        distance_matrix = torch.tensor(distance_matrix).to(hidden_states.device) # [0, L, L]
        
        attention_scores = attention_scores * distance_matrix[None, None, :, :] * opinion_transmission[:, None, None, :]

        attention_scores = attention_scores - torch.diag(torch.ones(seq_length, device=hidden_states.device))[None, None, :, :] * 10000.
        attention_scores = attention_scores + attention_mask

        # Normalize the attention scores to probabilities.
        attention_probs = nn.Softmax(dim=-1)(attention_scores)
        attention_probs = self.dropout(attention_probs)

        context_layer = torch.matmul(attention_probs, value_layer)

        context_layer = context_layer.permute(0, 2, 1, 3).contiguous()
        new_context_layer_shape = context_layer.size()[:-2] + (self.all_head_size,)
        context_layer = context_layer.view(*new_context_layer_shape)

        return context_layer
        

class ImnTransmission(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.self_attention = IMNSelfAttention(config)
        # self.self_attention = BertSelfAttention(config)
        self.self_output = BertSelfOutput(config)
        self.intermediate = BertIntermediate(config)
        self.output = BertOutput(config)

    def forward(self, hidden_states, opinion_transmission, attention_mask):
        attention_mask = (1 - attention_mask[:, None, None, :]) * -10000.
        
        attention_output = self.self_attention(hidden_states, opinion_transmission, attention_mask)
        
        # attention_output = self.self_attention(hidden_states, attention_mask=attention_mask)[0]
        self_output = self.self_output(attention_output, hidden_states)
        
        intermediate_output = self.intermediate(self_output)
        layer_output = self.output(intermediate_output, self_output)
        return layer_output
        

class Transmission(nn.Module):
    def __init__(self):
        super().__init__()
        self.fusion_layer = nn.Sequential(
            nn.Linear(config.hidden_size+1, config.hidden_size),
            nn.Tanh(),
        )
        self.LayerNorm = nn.LayerNorm(config.hidden_size, eps=config.layer_norm_eps)
        
    def forward(self, hidden_states, opinion_transmission, attention_mask):
        hidden_states_ = torch.cat((hidden_states, opinion_emission.unsqueeze(-1)), dim=-1)
        hidden_states_ = self.fusion_layer(hidden_states_)
        return self.LayerNorm(hidden_states + hidden_states_)


class grl_func(torch.autograd.Function):
    def __init__(self):
        super(grl_func, self).__init__()

    @ staticmethod
    def forward(ctx, x, lambda_):
        ctx.save_for_backward(lambda_)
        return x.view_as(x)

    @ staticmethod
    def backward(ctx, grad_output):
        lambda_, = ctx.saved_variables
        grad_input = grad_output.clone()
        # print(-lambda_ * grad_output[0, :10])
        return - lambda_ * grad_input, None


class GRL(nn.Module):
    def __init__(self, lambda_=0.):
        super(GRL, self).__init__()
        self.lambda_ = torch.tensor(lambda_)

    def set_lambda(self, lambda_):
        self.lambda_ = torch.tensor(lambda_)

    def forward(self, x):
        return grl_func.apply(x, self.lambda_)