import torch
import torch.nn as nn
import torch.nn.functional as F

from transformers.modeling_bert import BertPreTrainedModel
from transformers.modeling_bert import BertModel
from .crf import CRF
from specific.example import target_tagset as target_polarity_tagset


def distant_cross_entropy(logits, positions, mask=None):
    '''
    :param logits: [N, L]
    :param positions: [N, L]
    :param mask: [N]
    '''
    log_softmax = nn.LogSoftmax(dim=-1)
    log_probs = log_softmax(logits)
    if mask is not None:
        loss = -1 * torch.mean(torch.sum(positions.to(dtype=log_probs.dtype) * log_probs, dim=-1) /
                               (torch.sum(positions.to(dtype=log_probs.dtype), dim=-1) + mask.to(dtype=log_probs.dtype)))
    else:
        loss = -1 * torch.mean(torch.sum(positions.to(dtype=log_probs.dtype) * log_probs, dim=-1) /
                               torch.sum(positions.to(dtype=log_probs.dtype), dim=-1))
    return loss


class AsteModel(BertPreTrainedModel):
    def __init__(self, config):
        super().__init__(config)

        self.bert = BertModel(config)
        self.qa_outputs = nn.Linear(config.hidden_size, 2)

        self.reg = nn.Linear(config.hidden_size, 6) 

        # conv
        
        self.gate = nn.Sequential(
            nn.Linear(config.hidden_size*2, config.hidden_size),
            nn.ReLU()
        )

        self.conv_layer = nn.Conv2d(1, 768, (3, 768), padding=(1, 0))

        self.opinion_dense = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size),
            nn.ReLU()
        )

        self.crf = CRF(
            config.hidden_size, target_polarity_tagset.size(), target_polarity_tagset['SOS'],
            target_polarity_tagset['PAD'], dropout_prob=config.hidden_dropout_prob)

        self.init_weights()

    def conv(self, seq):
        # [B, 1, L, H] => [B, H, L, 1] => [B, H, L]
        seq = F.relu(self.conv_layer(seq.unsqueeze(1))).squeeze(-1)
        seq = seq.permute(0, 2, 1)
        return seq

    def inf_select(self, sequence_output, h_target):
        # [B, H] = > [B, 1, H]
        h_target = h_target.unsqueeze(1)
        L = sequence_output.size(1)
        gate = self.gate(torch.cat((sequence_output, h_target.repeat(1, L, 1)), dim=-1))
        return gate * sequence_output

    def target_tag(self, sequence_output, labels, attention_mask):
        attention_mask = attention_mask.type(torch.bool)
        # sequence_output = self.crf_dense(sequence_output)
        loss, y_preds = self.crf(sequence_output, labels, attention_mask)
        return loss, y_preds

    def target_span(self, h_target, sequence_output, start_positions, end_positions, n, attention_mask):
        n_loss, pn = self.n_pred(h_target, n)

        sequence_output = self.inf_select(sequence_output, h_target)
        logits = self.qa_outputs(sequence_output) - (1-attention_mask.unsqueeze(-1)) * 10000.
        
        start_logits, end_logits = logits.split(1, dim=-1)
        # [B, L]
        start_logits = start_logits.squeeze(-1)
        end_logits = end_logits.squeeze(-1)

        mask = (torch.sum(start_positions, dim=-1) > 0)
        if mask.any():
            start_loss = distant_cross_entropy(start_logits[mask], start_positions[mask])
            end_loss = distant_cross_entropy(end_logits[mask], end_positions[mask])
        else:
            start_loss = end_loss = 0
        
        return start_loss, end_loss, n_loss, start_logits, end_logits, pn

    def n_pred(self, pn_hidden, n):
        pn = self.reg(pn_hidden)
        n_loc = (n!=0)
        if n_loc.any():
            n_loss = F.cross_entropy(pn[n_loc], (n-1)[n_loc])
        else:
            n_loss = 0
        return n_loss, pn
    
    def forward(self, input_ids, attention_mask, token_type_ids,
                crf_tag, start_positions, end_positions, n):
        """
        input_ids, attention_mask, token_type_ids, crf_tag: [B, L]
        start_postions, end_positions: [B, L, L]
        n: [B, L]
        """
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )

        sequence_output = outputs[0]

        crf_loss, crf_preds = self.target_tag(sequence_output, crf_tag, attention_mask)
        target_seq = self.conv(sequence_output)
        L = sequence_output.size(1)

        start_loss = 0
        end_loss = 0
        n_loss = 0
        start_logits = torch.zeros_like(start_positions)
        end_logits = torch.zeros_like(start_positions)
        pn = [] # [(B, 6)]
        
        sequence_output = self.opinion_dense(sequence_output)

        for i in range(L):
            s_loss, e_loss, _n_loss, s_logits, e_logits, _pn = self.target_span(
                target_seq[:, i], 
                sequence_output, start_positions[:, i],
                end_positions[:, i], n[:, i], attention_mask
            )
            start_loss += s_loss
            end_loss += e_loss
            n_loss += _n_loss
            start_logits[:, i] = s_logits
            end_logits[:, i] = e_logits
            pn.append(_pn.unsqueeze(1))
        
        pn = torch.cat(pn, dim=1)
        # print(crf_loss.item(), start_loss.item(), end_loss.item(), n_loss.item())
        total_loss = crf_loss + (start_loss + end_loss)/2 + n_loss

        return total_loss, crf_preds, start_logits, end_logits, pn

