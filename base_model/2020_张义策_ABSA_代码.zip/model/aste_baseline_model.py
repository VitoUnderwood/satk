import torch
import torch.nn as nn 

from specific.example import opinion_tagset, target_polarity_tagset

from .crf import CRF
from transformers.modeling_bert import BertPreTrainedModel
from transformers.modeling_bert import BertModel


class TokenClassification(BertPreTrainedModel):
    def __init__(self, config, mode):
        super().__init__(config)
        self.bert = BertModel(config)
        self.mode = mode

        self.crf = CRF(
            config.hidden_size, opinion_tagset.size(), opinion_tagset['SOS'],
            opinion_tagset['PAD'], dropout_prob=config.hidden_dropout_prob)

        self.init_weights()

    def forward(self, input_ids, attention_mask, token_type_ids, labels):
        """
        input_ids, attention_mask, token_type_ids, labels: [B, L]
        """
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )

        sequence_output = outputs[0]

        attention_mask = attention_mask.type(torch.bool)
        loss, y_preds = self.crf(sequence_output, labels, attention_mask)
        
        return loss, y_preds


class SpanExtraction(BertPreTrainedModel):
    def __init__(self, config, mode):
        pass
