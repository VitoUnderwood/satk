import torch
import torch.nn as nn
import torch.nn.functional as F

from .layers import AttentionMerge


def distant_cross_entropy(logits, positions, mask=None):
    '''
    :param logits: [N, L]
    :param positions: [N, L]
    :param mask: [N]
    '''
    log_softmax = nn.LogSoftmax(dim=-1)
    log_probs = log_softmax(logits)
    if mask is not None:
        loss = -1 * torch.mean(torch.sum(positions.to(dtype=log_probs.dtype) * log_probs, dim=-1) /
                               (torch.sum(positions.to(dtype=log_probs.dtype), dim=-1) + mask.to(dtype=log_probs.dtype)))
    else:
        loss = -1 * torch.mean(torch.sum(positions.to(dtype=log_probs.dtype) * log_probs, dim=-1) /
                               torch.sum(positions.to(dtype=log_probs.dtype), dim=-1))
    return loss


class SpanModel(nn.Module):
    def __init__(self, hidden_size=768, n_span=4):
        super().__init__()

        self.n_span_layer = nn.Sequential(
            nn.Linear(hidden_size+1, hidden_size+1),
            nn.Tanh(),
            nn.Dropout(0.1),
            nn.Linear(hidden_size+1, n_span) 
        )
        self.qa_outputs = nn.Sequential(
            nn.Linear(hidden_size, 2)
        )

        self.att_merge = AttentionMerge(768, 256, 0.1)

    def span_predict(self, sequence_output, attention_mask):
        """
        sequence_ouptput: [B, L, H]
        attention_mask: [B, L]
        start_positions, end_positions: [B, L]
        """
        logits = self.qa_outputs(sequence_output) - (1-attention_mask.unsqueeze(-1)) * 10000.        
        start_logits, end_logits = logits.split(1, dim=-1)
        # [B, L]
        start_logits = start_logits.squeeze(-1)
        end_logits = end_logits.squeeze(-1)
        
        return start_logits, end_logits

    def span_forward(self, sequence_output, attention_mask,
                     start_positions, end_positions):
        """
        sequence_ouptput: [B, L, H]
        attention_mask: [B, L]
        start_positions, end_positions: [B, L]
        """
        logits = self.qa_outputs(sequence_output) - (1-attention_mask.unsqueeze(-1)) * 10000.        
        start_logits, end_logits = logits.split(1, dim=-1)
        # [B, L]
        start_logits = start_logits.squeeze(-1)
        end_logits = end_logits.squeeze(-1)

        mask = (torch.sum(start_positions, dim=-1) > 0)

        if mask.any():
            start_loss = distant_cross_entropy(start_logits[mask], start_positions[mask])
            end_loss = distant_cross_entropy(end_logits[mask], end_positions[mask])
            span_loss = (start_loss + end_loss)  # torch.sum(mask) * sequence_output.size(0)
        else:
            span_loss = 0
        
        return span_loss, start_logits, end_logits, torch.sum(mask)

    def n_predict(self, sequence_output, mask, start_logits, end_logits):
        """
        sequence_output: [B, L, H]
        mask: [B, L]
        n_true: [B,]
        start_logits, end_logits: [B, L]
        """
        h_target1 = torch.max(sequence_output * mask.unsqueeze(-1), dim=1)[0]
        h_target2 = torch.sum(F.relu(start_logits * mask), dim=-1, keepdim=True)
        h_target3 = torch.sum(F.relu(end_logits * mask), dim=-1, keepdim=True)

        h_target = torch.cat((h_target1, h_target2 + h_target3), dim=-1)

        n_pred = self.n_span_layer(h_target)
        n_pred = n_pred.argmax(dim=-1) + 1
        return n_pred

    def n_forward(self, sequence_output, mask, start_logits, end_logits, n_true):
        """
        sequence_output: [B, L, H]
        mask: [B, L]
        n_true: [B,]
        start_logits, end_logits: [B, L]
        """
        h_target1 = torch.max(sequence_output * mask.unsqueeze(-1), dim=1)[0]
        # h_target1 = sequence_output[:, 0]
        # h_target1 = self.att_merge(sequence_output, mask)[0]
        
        h_target2 = torch.sum(F.relu(start_logits * mask), dim=-1, keepdim=True)
        h_target3 = torch.sum(F.relu(end_logits * mask), dim=-1, keepdim=True)

        h_target = torch.cat((h_target1, h_target2 + h_target3), dim=-1)

        n_pred = self.n_span_layer(h_target)
        n_loc = (n_true!=0)

        if n_loc.any():
            n_loss = F.cross_entropy(n_pred[n_loc], (n_true-1)[n_loc])
        else:
            n_loss = 0

        n_pred = n_pred.argmax(dim=-1) + 1
        return n_loss, n_pred