import torch
import torch.nn as nn
import torch.nn.functional as F

from transformers.modeling_bert import BertPreTrainedModel
from transformers.modeling_bert import BertModel, BertAttention, BertLayer, BertSelfAttention


def distant_cross_entropy(logits, positions, mask=None):
    '''
    :param logits: [N, L]
    :param positions: [N, L]
    :param mask: [N]
    '''
    log_softmax = nn.LogSoftmax(dim=-1)
    log_probs = log_softmax(logits)
    if mask is not None:
        loss = -1 * torch.mean(torch.sum(positions.to(dtype=log_probs.dtype) * log_probs, dim=-1) /
                               (torch.sum(positions.to(dtype=log_probs.dtype), dim=-1) + mask.to(dtype=log_probs.dtype)))
    else:
        loss = -1 * torch.mean(torch.sum(positions.to(dtype=log_probs.dtype) * log_probs, dim=-1) /
                               torch.sum(positions.to(dtype=log_probs.dtype), dim=-1))
    return loss


class SpanModel(nn.Module):
    def __init__(self, hidden_size=768):
        super().__init__()

        self.reg_layer = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_size, 4) 
        )
        self.qa_outputs = nn.Sequential(
            nn.Linear(hidden_size, 2)
        )

    def span_forward(self, sequence_output, attention_mask,
                start_positions, end_positions):
        """
        sequence: [B, L, H]
        attention_mask: [B, L]
        start_positions, end_positions: [B, L]
        n: [B, ]
        """
        logits = self.qa_outputs(sequence_output) - (1-attention_mask.unsqueeze(-1)) * 10000.        
        start_logits, end_logits = logits.split(1, dim=-1)
        # [B, L]
        start_logits = start_logits.squeeze(-1)
        end_logits = end_logits.squeeze(-1)

        mask = (torch.sum(start_positions, dim=-1) > 0)

        if mask.any():
            start_loss = distant_cross_entropy(start_logits[mask], start_positions[mask])
            end_loss = distant_cross_entropy(end_logits[mask], end_positions[mask])
            span_loss = (start_loss + end_loss)  # torch.sum(mask) * sequence_output.size(0)
        else:
            span_loss = 0
        
        return span_loss, start_logits, end_logits, torch.sum(mask)

    def n_forward(self, hidden, n_true):
        n_pred = self.reg_layer(hidden)
        n_loc = (n_true!=0)
        if n_loc.any():
            n_loss = F.cross_entropy(n_pred[n_loc], (n_true-1)[n_loc])
        else:
            n_loss = 0
        return n_loss, n_pred


class AsteModel(BertPreTrainedModel):
    def __init__(self, config):
        super().__init__(config)

        self.bert = BertModel(config)

        self.span_target = SpanModel(config.hidden_size)
        self.span_opinion = SpanModel(config.hidden_size)
        self.span_target_opinion = SpanModel(config.hidden_size)

        self.taregt_dense  = BertAttention(config)
        self.opinion_dense = BertAttention(config)
        # self.polarity_dense = BertAttention(config)

        self.polarity_classifier = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size),
            nn.ReLU(),
            nn.Linear(config.hidden_size, 3)
        )

        self.conv_layer_1 = nn.Conv2d(1, 768, (3, 768), padding=(1, 0))
        self.conv_layer_2 = nn.Conv2d(1, 768, (3, 768), padding=(1, 0))

        self.gate_layer = nn.Sequential(
            nn.Linear(config.hidden_size*2, config.hidden_size),
            nn.ReLU()
        )

        self.init_weights()

    def conv(self, conv_layer, seq):
        # [B, 1, L, H] => [B, H, L, 1] => [B, H, L]
        seq = F.relu(conv_layer(seq.unsqueeze(1))).squeeze(-1)
        seq = seq.permute(0, 2, 1)
        return seq

    def gate(self, seq, q):
        L = seq.size(1)
        # [B, L, H]
        gate_i = self.gate_layer(torch.cat((q.unsqueeze(1).repeat(1,L,1), seq), dim=2))
        return (gate_i * seq)

    def span_forward(self, span_model, sequence, attention_mask,
                     start_positions, end_positions, n_span):
        span_loss, start_logits, end_logits, m = span_model.span_forward(
            sequence, attention_mask, start_positions, end_positions)

        n_loss, pn = span_model.n_forward(sequence[:, 0], n_span)

        return span_loss + n_loss, start_logits, end_logits, pn, m

    def forward(self, input_ids, attention_mask, token_type_ids,
                start_positions_target, end_positions_target, polarity_target, n_target,
                start_positions_opinion, end_positions_opinion, polarity_opinion, n_opinion,
                start_positions_target_opinion, end_positions_target_opinion, n_target_opinion):
        """
        input_ids, attention_mask, token_type_ids, ts, te, tp, tn, os, oe, op, on, tos, toe, ton

        input_ids, attention_mask, token_type_ids: [B, L]
        start_positions_target, end_positions_target, polarity_target: [B, L]
        start_positions_opinion, end_positions_opinion, polarity_opinion: [B, L]
        start_positions_target_opinion, end_positions_target_opinion: [B, L, L]
        n_target, n_opinion: [B, ]
        n_target_opinion: [B, L]
        """
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )

        sequence_output = outputs[0]
        L = sequence_output.size(1)

        extended_attention_mask = attention_mask[:, None, None, :]
        extended_attention_mask = (1.0 - extended_attention_mask) * -10000.0

        target_sequence = self.taregt_dense(sequence_output, extended_attention_mask)[0]
        opinion_sequence = self.opinion_dense(sequence_output, extended_attention_mask)[0]
        target_polarity_sequence = self.taregt_dense(sequence_output, extended_attention_mask)[0]
        opinion_polarity_sequence = self.opinion_dense(sequence_output, extended_attention_mask)[0]

        ##########################################################################
        target_loss, target_start_logits, target_end_logits, target_pn, _ = self.span_forward(
            self.span_target, target_sequence, attention_mask,
            start_positions_target, end_positions_target, n_target
        )

        target_sequence = self.conv(self.conv_layer_1, target_sequence)
        target_sequence = self.conv(self.conv_layer_2, target_sequence)

        ##########################################################################

        opinion_loss, opinion_start_logits, opinion_end_logits, opinion_pn, _ = self.span_forward(
            self.span_opinion, opinion_sequence, attention_mask,
            start_positions_opinion, end_positions_opinion, n_opinion
        )

        ##########################################################################

        to_loss = 0
        to_start_logits = torch.zeros_like(start_positions_target_opinion)
        to_end_logits = torch.zeros_like(end_positions_target_opinion)
        to_pn = [] # [(B, 6)]
        m_sum = 0

        for i in range(L):
            target_sequence_i = target_sequence[:, i]
            opinion_sequence_i = self.gate(opinion_sequence, target_sequence_i)

            span_loss, start_logits, end_logits, pn, m = self.span_forward(
                self.span_target_opinion, opinion_sequence_i, attention_mask,
                start_positions_target_opinion[:,i], end_positions_target_opinion[:,i], n_target_opinion[:,i]
            )
    
            to_start_logits[:, i] = start_logits
            to_end_logits[:, i] = end_logits
            to_pn.append(pn.unsqueeze(1))
            m_sum += m
            
            to_loss += span_loss*m.type(torch.float)
        
        to_loss = to_loss / m_sum
        to_pn = torch.cat(to_pn, dim=1)  # [B, L, 6]
        
        ##########################################################################
        polarity_to = torch.zeros_like(polarity_target) - 1
        polarity_to[polarity_target!=-1] = polarity_target[polarity_target!=-1]
        polarity_to[polarity_opinion!=-1] = polarity_opinion[polarity_opinion!=-1]

        target_polarity_loss, target_polarity = self.polarity_forward(
            self.polarity_classifier, target_polarity_sequence, polarity_to)

        opinion_polarity_loss, opinion_polarity = self.polarity_forward(
            self.polarity_classifier, opinion_polarity_sequence, polarity_to)

        # target_polarity = opinion_polarity = to_polarity
        polarity_loss = target_polarity_loss + opinion_polarity_loss
        ##########################################################################

        total_loss = target_loss + polarity_loss + opinion_loss + to_loss
        # total_loss = target_loss + polarity_loss # + to_loss
        # print('\n', t_p_loss.item(), o_p_loss.item(), )

        return (total_loss, target_start_logits, target_end_logits, target_polarity, target_pn,
                            opinion_start_logits, opinion_end_logits, opinion_polarity, opinion_pn,
                            to_start_logits, to_end_logits, to_pn)

    def polarity_forward(self, layer, seq, polarity_true):
        """
        sequence_output: [B, L, H]
        polarity_target: [B, L]
        """ 
        polarity_logits = layer(seq)

        loc = (polarity_true != -1)
        loss = F.cross_entropy(polarity_logits[loc], polarity_true[loc])

        return loss, polarity_logits

        # t_p_loss, t_po, o_p_loss, o_po = self.polarity_forward(
        #     self.polarity_target,
        #     target_sequence, opinion_sequence_polarity,
        #     polarity_target, polarity_opinion)



