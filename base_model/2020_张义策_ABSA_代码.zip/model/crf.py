import torch
import torch.nn as nn

from torch.autograd import Variable
from . import log_sum_exp, init_linear


try:
    from allennlp.modules.conditional_random_field import ConditionalRandomField

    class AllenNlpCRF(nn.Module):
        def __init__(self, hidden_size, tag_size, start_tag, end_tag, dropout_prob):
            super(AllenNlpCRF, self).__init__()
            self.hidden_size = hidden_size
            self.hidden2tag = nn.Sequential(
                nn.Dropout(dropout_prob),
                nn.Linear(hidden_size, tag_size)
            )

            self.crf = ConditionalRandomField(tag_size, include_start_end_transitions=False)

        def forward(self, hidden, labels, mask):
            emission = self.hidden2tag(hidden)
            loss = - self.crf(emission, labels, mask) / mask.size(0)
            predicts = self.crf.viterbi_tags(emission, mask)
            predicts = self._predict_to_tensor(predicts, mask.size(1), mask.device)
            return loss, predicts

        def loss(self, hidden, labels, mask):
            emission = self.hidden2tag(hidden)
            loss = - self.crf(emission, labels, mask) / mask.size(0)
            return loss

        def predict(self, hidden, mask):
            emission = self.hidden2tag(hidden)
            predicts = self.crf.viterbi_tags(emission, mask)
            predicts = self._predict_to_tensor(predicts, mask.size(1), mask.device)
            return predicts

        def _predict_to_tensor(self, predicts, seq_length, device):
            # [([tag1, ...],score), ]
            p_tensor = torch.zeros((len(predicts), seq_length)).type(torch.long)
            for idx, line in enumerate(predicts):
                p_tensor[idx, :len(line[0])] = torch.LongTensor(line[0])
            return p_tensor.to(device)

except ModuleNotFoundError:
    class AllenNlpCRF:
        def __init__(self):
            pass


"""
CRFS
    self.forward(h, l, m) -> loss, predicts
    self.predict(h, m) -> predicts
"""


class CRF(nn.Module):
    """
    参考自 https://github.com/ZhixiuYe/HSCRF-pytorch/blob/master/model/crf_layer.py
    self.forward(hidden, labels, mask) -> loss, predict_tags
    self.predict(hidden, mask) -> predict_tags
    """
    def __init__(self, hidden_size, tag_size,
                 start_tag, end_tag, dropout_prob):

        super(CRF, self).__init__()
        self.hidden_size = hidden_size
        self.tag_size = tag_size
        self.start_tag = start_tag
        self.end_tag = end_tag
        self.dropout_prob = dropout_prob

        self.hidden2tag = nn.Sequential(
            # nn.Linear(hidden_size, hidden_size),
            # nn.Tanh(),
            nn.Dropout(dropout_prob),
            nn.Linear(hidden_size, tag_size))

        self.transition = nn.Parameter(
            torch.ones(tag_size, tag_size) * 1 / tag_size)

        self.rand_init()

    def rand_init(self):
        init_linear(self.hidden2tag[1])
        # init_linear(self.hidden2tag[3])
        self.transition.data[:, self.start_tag] = 0.
        self.transition.data[self.end_tag, :]   = 0.

    def cal_score(self, hidden, mask):
        # [batch_size, sent_len, tag_size]
        emission = self.hidden2tag(hidden)
        # tag_scores = emission.clone()
        # [batch_size, sent_len, tag_size, tag_size]
        emission = emission.unsqueeze(2).expand(-1, -1, self.tag_size, -1)
        crf_scores = emission + self.transition.unsqueeze(0)
        return crf_scores

    def forward(self, hidden, labels, mask):
        """
        hidden: [batch_size, sent_len, hidden_size]
        labels: [batch_size, sent_len]
        mask: [batch_size, sent_len]
        """
        # [batch_size, sent_len, tag_size, tag_size]
        crf_scores = self.cal_score(hidden, mask)
        loss = self.cal_loss(crf_scores, labels, mask)
        decode_idx = self.decode(crf_scores, mask)
        return loss, decode_idx

    def loss(self, hidden, labels, mask):
        crf_scores = self.cal_score(hidden, mask)
        loss = self.cal_loss(crf_scores, labels, mask)
        return loss

    def predict(self, hidden, mask):
        """
        hidden: [batch_size, sent_len, hidden_size]
        mask: [batch_size, sent_len]
        """
        # [batch_size, sent_len, tag_size, tag_size]
        crf_scores = self.cal_score(hidden, mask)
        decode_idx = self.decode(crf_scores, mask)
        return decode_idx

    def cal_loss(self, crf_scores, targets, mask):
        """
        crf_scores: [batch_size, sent_len, tag_size, tag_size]
        labels: [batch_size, sent_len]
        mask: [batch_size, sent_len]
        """
        batch_size, sent_len = mask.size()

        tg_energy = torch.gather(crf_scores.view(batch_size, sent_len, -1),
                                 2, targets.unsqueeze(2)
                                 ).view(batch_size, sent_len)
        tg_energy = tg_energy.masked_select(mask).sum()

        # [batch_size, tag_size, tag_size]
        inivalues = crf_scores[:, 0]
        partition = inivalues[:, self.start_tag, :].clone()
        for idx in range(1, sent_len):
            # [batch_size, tag_size, tag_size]
            cur_values = crf_scores[:, idx]
            cur_values = cur_values + partition.contiguous().view(
                batch_size, self.tag_size, 1).expand(
                batch_size, self.tag_size, self.tag_size)
            cur_partition = log_sum_exp(cur_values, self.tag_size)
            mask_idx = mask[:, idx].view(batch_size, 1).expand(
                batch_size, self.tag_size)
            partition.masked_scatter_(mask_idx,
                                      cur_partition.masked_select(mask_idx))

        partition = partition[:, self.end_tag].sum()
        loss = (partition - tg_energy) / batch_size
        # loss = (partition - tg_energy) / torch.sum(mask)
        return loss

    def decode(self, crf_scores, mask):
        batch_size, sent_len = mask.size()

        # mask = Variable(1 - mask.data)
        mask = ~mask
        decode_idx = Variable(torch.cuda.LongTensor(batch_size, sent_len-1))

        inivalues = crf_scores[:, 0]
        forscores = inivalues[:, self.start_tag, :]
        back_points = list()
        for idx in range(1, sent_len):
            cur_values = crf_scores[:, idx]
            cur_values = cur_values + forscores.contiguous().view(
                batch_size, self.tag_size, 1).expand(
                batch_size, self.tag_size, self.tag_size)
            forscores, cur_bp = torch.max(cur_values, 1)
            cur_bp.masked_fill_(mask[:, idx].view(batch_size, 1).expand(
                batch_size, self.tag_size), self.end_tag)
            back_points.append(cur_bp)

        pointer = back_points[-1][:, self.end_tag]
        decode_idx[:, -1] = pointer
        for idx in range(len(back_points)-2, -1, -1):
            pointer = torch.gather(back_points[idx], 1,
                                   pointer.contiguous().view(batch_size, 1))
            decode_idx[:, idx] = pointer.view(-1, )
        return decode_idx
