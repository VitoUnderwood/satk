import torch
import torch.nn as nn
import torch.nn.functional as F

from transformers.modeling_bert import BertPreTrainedModel
from transformers.modeling_bert import BertModel

from ._span_model import SpanModel


class SpanExtraction(BertPreTrainedModel):
    def __init__(self, config, mode):
        super().__init__(config)

        self.mode = mode

        self.bert = BertModel(config)
        self.span_model = SpanModel(hidden_size=768, n_span=4)

        if 'gate' in mode:
            self.gate = nn.Sequential(
                nn.Linear(config.hidden_size*2, config.hidden_size),
                nn.ReLU()
            )

        self.init_weights()
    
    # def conv(self, conv_layer, seq):
    #     # [B, 1, L, H] => [B, H, L, 1] => [B, H, L]
    #     seq = F.relu(conv_layer(seq.unsqueeze(1))).squeeze(-1)
    #     seq = seq.permute(0, 2, 1)
    #     return seq

    def inf_select(self, sequence_output, attention_mask, token_type_ids):
        # 1 1 1 1 1 1 0 0 0
        # 0 0 0 0 1 1 0 0 0
        target_mask = attention_mask * token_type_ids
        # [B, H]
        h_target = torch.max(target_mask.unsqueeze(-1) * sequence_output, dim=1)[0]
        h_target = h_target.unsqueeze(1)
        L = sequence_output.size(1)

        gate = self.gate(torch.cat((sequence_output, h_target.repeat(1, L, 1)), dim=-1))
        return gate * sequence_output

    def forward(self, input_ids, attention_mask, token_type_ids, start_positions, end_positions, n):
        """
        input_ids, attention_mask, token_type_ids: [B, L]
        start_postions, end_positions: [B, L]
        """
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )

        sequence_output = outputs[0]
        # if 'gate' in self.mode:
        #     sequence_output = self.inf_select(sequence_output, attention_mask, token_type_ids)

        seq_mask = attention_mask - token_type_ids
        span_loss, start_logits, end_logits, _ = self.span_model.span_forward(
            sequence_output, seq_mask, start_positions, end_positions
        )

        # sequence_output = self.conv(self.conv_layer_1, sequence_output)
        # sequence_output = self.conv(self.conv_layer_2, sequence_output)

        # h_target = self.att_merge(sequence_output, seq_mask)[0]
        # sequence_output = sequence_output - (1-seq_mask).unsqueeze(-1) * 10000
        # h_target = torch.max(sequence_output, dim=1)[0]
        # h_target = torch.sum(seq_mask.unsqueeze(-1) * sequence_output, dim=1)[0]
        # h_target = h_target / seq_mask.sum(dim=-1).unsqueeze(-1)
        # h_target = sequence_output[:, 0]

        n_loss, pn = self.span_model.n_forward(
            sequence_output, seq_mask, 
            start_logits.detach(), end_logits.detach(), n)            

        total_loss = span_loss/2 + n_loss
        return total_loss, start_logits, end_logits, pn

    def predict(self, input_ids, attention_mask, token_type_ids):
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )

        sequence_output = outputs[0]

        seq_mask = attention_mask - token_type_ids
        start_logits, end_logits = self.span_model.span_predict(
            sequence_output, seq_mask)
        
        n_pred = self.span_model.n_predict(
            sequence_output, seq_mask, start_logits, end_logits)

        return start_logits, end_logits, n_pred
