import torch
import torch.nn as nn
import torch.nn.functional as F


import os
import math
from collections import defaultdict

from utils import mkdir_if_notexist
from specific.example import opinion_tagset, target_tagset

from .modeling_bert import BertModel
from .crf import CRF
from .layers import ImnTransmission, Transmission
from transformers.modeling_bert import BertPreTrainedModel


class TokenClassification(BertPreTrainedModel):
    def __init__(self, config):
        super().__init__(config)
        self.bert = BertModel(config)

        self.crf = CRF(
            config.hidden_size, opinion_tagset.size(), opinion_tagset['SOS'],
            opinion_tagset['PAD'], dropout_prob=config.hidden_dropout_prob)

        self.init_weights()

    def forward(self, input_ids, attention_mask, token_type_ids, labels):
        """
        input_ids, attention_mask, token_type_ids, labels: [B, L]
        """
        attention_mask = attention_mask - token_type_ids

        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )

        sequence_output = outputs[0]
        # sequence_output = outputs[2][-2]

        attention_mask = attention_mask.type(torch.bool)
        loss, y_preds = self.crf(sequence_output, labels, attention_mask)
        emission = self.crf.hidden2tag(outputs[0])

        return loss, emission, y_preds


class SequenceClassification(BertPreTrainedModel):
    def __init__(self, config, mode='asc-only', gamma=0., f_map='linear'):
        super().__init__(config)
        assert mode in ('asc-only', 'highlight-target', 'highlight-all', 'transmission')

        self.mode = mode
        self.f_map = f_map
        self.gamma = gamma
        # config.output_attentions = True

        print(f'absa: {mode}, gamma: {gamma}, f_map: {f_map}')

        # if mode == 'highlight':
        # self.grl_layer = GRL(lambda_=-1)

        self.bert = BertModel(config)

        if self.mode == 'transmission':
            self.transmission = Transmission(config)
            # self.transmission = ImnTransmission(config)

        self.classifier = nn.Sequential(
            # nn.Linear(config.hidden_size, config.hidden_size),
            # nn.Tanh(),
            nn.Dropout(config.hidden_dropout_prob),
            nn.Linear(config.hidden_size, 4),
        )

        self.init_weights()

    def forward(self, input_ids, attention_mask, token_type_ids, labels,
                target_labels, opinion_labels, opinion_emission=None, lambda_=0):
        """
        input_ids, attention_mask, token_type_ids: [B, L]
        labels: [B,]
        """

        active_loc = (labels != -1)
        input_ids = input_ids[active_loc]
        attention_mask = attention_mask[active_loc]
        token_type_ids = token_type_ids[active_loc]
        labels = labels[active_loc]
        target_labels = target_labels[active_loc]

        if opinion_emission is not None:
            opinion_emission = opinion_emission[active_loc]
            opinion_emission1 = opinion_emission[..., opinion_tagset['B-opinion']]
            opinion_emission2 = opinion_emission[..., opinion_tagset['I-opinion']]
            opinion_emission = opinion_emission1 + opinion_emission2

        else:
            opinion_labels = opinion_labels[active_loc]
            # batch_size, length = opinion_labels.size()  # (B, L)
            # emission = torch.zeros(batch_size, length, opinion_tagset.size()).to(opinion_labels.device).scatter_(
            #   dim=2, index=opinion_labels.unsqueeze(-1), src=torch.tensor(1.),
            # )
            opinion_emission1 = (opinion_labels == opinion_tagset['B-opinion'])
            opinion_emission2 = (opinion_labels == opinion_tagset['I-opinion'])
            opinion_emission = (opinion_emission1 + opinion_emission2).type(torch.float)

        target_emission1 = (target_labels == target_tagset['B-target'])
        target_emission2 = (target_labels == target_tagset['I-target'])
        target_emission = (target_emission1 + target_emission2).type(torch.float)

        return self._forward(input_ids, attention_mask, token_type_ids, labels,
                             target_emission, opinion_emission)

    def _forward(self, input_ids, attention_mask, token_type_ids, labels,
                 target_emission, opinion_emission):

        if self.mode in ('asc-only', 'transmission'):
            highlight_score = None

        elif self.mode in ('highlight-target', 'highlight-all'):
            highlight_score = self.opinion_score(opinion_emission, target_emission)

        bert_output = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            highlight_score=highlight_score
        )

        sequence_output = bert_output[0]
        # attentions = bert_output[2]
        # attentions = torch.cat(bert_output[2], dim=1)
        
        if self.mode == 'transmission':
            sequence_output = self.transmission(sequence_output, opinion_emission, attention_mask)
            
        # => [B, H]
        h = torch.max(target_emission.unsqueeze(-1) * sequence_output, dim=1)[0]

        logits = self.classifier(h)
        loss = F.cross_entropy(logits, labels)

        return loss, logits

    def opinion_score(self, opinion_emission, target_emission):
        """
        emission: [B, L, N]
        return: [B, 1 or L, L] or None
        """

        # => [B, 1, L]
        opinion_score = opinion_emission.unsqueeze(-2)

        if self.mode == 'highlight-target':
            # => [B, L, 1]
            target_emission = target_emission.unsqueeze(-1)

            # => [B, L, L]
            opinion_score = opinion_score * target_emission

        # 加一个随机扰动
        # 或者随机强调
        return self.map_func(opinion_score)

    def map_func(self, X):
        if self.f_map == 'linear':
            # return X * self.gamma
            return F.relu(X - 0.5) / 0.5 * self.gamma
            # return opinion_score * (opinion_score>0.5) * self.gamma

        elif self.f_map == 'log':
            return torch.log(X + 1) / math.log(2) * self.gamma

        elif self.f_map == 'square':
            return X ** 2 * self.gamma


class Model(nn.Module):
    def __init__(self, asc_opinion, model_type=None):
        super().__init__()

        self.models = asc_opinion
        self.model_type = model_type

        print(f'model_type: {model_type}')

    def to(self, device):
        for model in self.models.values():
            if model is not None:
                model.to(device)
        return self

    def parameters(self):
        for model in self.models.values():
            if model is not None:
                yield from model.parameters()

    def named_parameters(self):
        for model in self.models.values():
            if model is not None:
                yield from model.named_parameters()

    @classmethod
    def from_pretrained(cls, naive_bert_path, task_bert_path, f_map,
                        gamma, model_type, *model_args, **kwargs):

        assert model_type in ('asc-only', 'opinion-only', 'highlight-target', 'highlight-all', 'transmission'), model_type

        asc_path = os.path.join(task_bert_path, 'asc-only/asc')
        opinion_path = os.path.join(task_bert_path, 'opinion-only/opinion')

        if model_type in ('asc-only',):
            asc_model = SequenceClassification.from_pretrained(
                naive_bert_path, mode=model_type, *model_args, **kwargs)
            opinion_model = None

        elif model_type == 'opinion-only':
            asc_model = None
            opinion_model = TokenClassification.from_pretrained(
                naive_bert_path, *model_args, **kwargs)

        elif model_type in ('highlight-target', 'highlight-all', 'transmission'):
            opinion_model = TokenClassification.from_pretrained(
                opinion_path, *model_args, **kwargs)
            # opinion_model = None
            asc_model = SequenceClassification.from_pretrained(
                asc_path, mode=model_type, gamma=gamma, f_map=f_map,
                *model_args, **kwargs)

        absa_highlight_mask_opinion = {
            'asc': asc_model,
            'opinion': opinion_model
        }

        # opinion_model.bert = absa_model.bert
        return cls(absa_highlight_mask_opinion, model_type=model_type)

    def save_pretrained(self, output_model_dir):
        output_model_dir = os.path.join(output_model_dir, self.model_type)

        for name, model in self.models.items():
            if model is not None:
                model_dir = os.path.join(output_model_dir, name)
                mkdir_if_notexist(model_dir + '/')
                model.save_pretrained(model_dir)
                print(f'save {name}_model to {model_dir}')

    def forward(self, input_ids, attention_mask, token_type_ids,
                opinion_labels, target_labels, absa_labels, lambda_):

        loss = defaultdict(int)
        pred = defaultdict(lambda: None)
        # atte = defaultdict(lambda: None)

        model = self.models['opinion']
        if model is not None:
            loss['opinion'], pred['opinion_emission'], pred['opinion'] = model(
                input_ids, attention_mask, token_type_ids, opinion_labels)

        model = self.models['asc']
        if model is not None:
            loss['asc'], pred['asc'] = model(
                input_ids, attention_mask, token_type_ids, absa_labels,
                target_labels, opinion_labels, pred['opinion_emission'], lambda_)

        overall_loss = loss['opinion'] + loss['asc']
        return overall_loss, loss, pred
