class Tagset:
    """
    self.make_bio_idx(entities, tokens, max_seq_length)
    """
    def __init__(self, tags):
        self.tag_to_idx = self._to_idx(tags)
        self.idx_to_tag = self._to_tag(tags)

    def _to_tag(self, tags):
        return dict((k, v) for k, v in enumerate(tags))

    def _to_idx(self, tags):
        return dict((k, v) for v, k in enumerate(tags))

    def __getitem__(self, tag):
        return self.tag_to_idx[tag]

    def size(self):
        return len(self.tag_to_idx)

    def is_entity(self, idx):
        if idx not in (
            self.tag_to_idx['PAD'],
            self.tag_to_idx['SOS'],
            self.tag_to_idx['O'],
        ):
            return True
        else:
            return False

    def make_bio_idx(self, entities, tokens, text, max_seq_length):
        bio_seq = from_entities_to_bio(entities, tokens, text)
        bio_seq = ['SOS'] + bio_seq
        bio_seq += ['PAD'] * (max_seq_length - len(bio_seq))
        return self.from_tag_seq_to_idx_seq(bio_seq)

    def from_tag_seq_to_idx_seq(self, tag_seq):
        return [self.tag_to_idx[tag] for tag in tag_seq]

    def from_idx_seq_to_tag_seq(self, idx_seq):
        return [self.idx_to_tag[idx] for idx in idx_seq if self.idx_to_tag[idx] != 'PAD']

    def parse_idx(self, idx_seq):
        bio_seq = self.from_idx_seq_to_tag_seq(idx_seq)
        return from_bio_to_entites(bio_seq), bio_seq


def _begin_here(word_start, word_end, term_start):
    return word_start <= term_start <= word_end-1


def _end_before(word_start, term_end):
    return term_end <= word_start


def from_entities_to_bio(entities, tokens, text, tokenizer_type='bert'):
    """
    根据实体构建bio序列
    """
    _entities = [e for e in entities]

    loc = [(-1, 0)]

    if tokenizer_type == 'bert':
        for token in tokens:
            start = loc[-1][1]
            token = token.replace('##', '')
            end = start + len(token)
            if text[start:end] != token:
                start += 1
                end += 1
            assert text[start:end] == token, f'{text}\n{text[start:end]}\n{tokens}\n{token}'
            loc.append((start, end))

    else:
        for token in tokens:
            start = loc[-1][1]
            end = start + len(token)
            loc.append((start, end))

    result_seq = ['O']
    if entities:
        entity = entities.pop()
    else:
        return ['O'] * (len(loc) - 1)

    for i, (start, end) in enumerate(loc[1:]):
        if result_seq[-1][0] == 'O':
            if _begin_here(start, end, entity[1]):
                result_seq.append(f'B-{entity[0]}')
            else:
                result_seq.append('O')

        elif result_seq[-1][0] in ('B', 'I'):
            if _end_before(start, entity[2]):
                last_entity = entity
                entity = pop_entity(entities, last_entity)

                if entity:
                    if _begin_here(start, end, entity[1]):
                        result_seq.append(f'B-{entity[0]}')
                    else:
                        result_seq.append('O')
                else:
                    result_seq += ['O'] * (len(loc) - len(result_seq))
                    return result_seq[1:]

            else:
                result_seq.append(f'I-{entity[0]}')

    assert len(entities) <= 1, f'\n{entities}\n{_entities}\n{tokens}'
    return result_seq[1:]


def pop_entity(entities, last_entity):
    if entities:
        entity = entities.pop()
        if last_entity[1] <= entity[1] < last_entity[2]:
            assert entity[2] <= last_entity[2], f'{entity}, {last_entity}'
            print(f'只保留长实体, {entity}, {last_entity}')
            return pop_entity(entities, last_entity)
        else:
            return entity
    else:
        return None


def from_bio_to_entites(bio_seq):
    """
    从bio序列中解析得到实体

    bio: ['O', O', 'B-type', 'I-type', 'O', 'PAD']
    labels: [(type, 2, 4),]
    """
    entities = []
    state = 'O'
    entity = ()

    for i, bio in enumerate(bio_seq):
        if state == 'O':
            if bio[0] == 'B':
                entity = (bio[2:], i)

        elif state in ('B', 'I'):
            if bio[0] in ('O', 'B'):
                entity += (i,)
                entities.append(entity)

            if bio[0] == 'B':
                entity = (bio[2:], i)

        state = 'O' if bio in ('PAD', 'SOS') else bio[0]

    # O O B (I)
    if len(entity) == 2:
        entity += (i+1, )
        entities.append(entity)

    return [entity for entity in entities if len(entity) == 3 and type(entity[0]) is str]
