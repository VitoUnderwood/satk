#!/bin/bash


while getopts ':d:' opt
do
    case $opt in
        d)
        dataset="$OPTARG" ;;
        ?)
        echo "未知参数"
        exit 1;;
    esac
done

echo "dataset=$dataset"

python aste.py\
    --train_file_name aste/$dataset/train.json\
    --test_file_name aste/$dataset/test.json\
    --bert_model_dir ../../data/\
    --bert_vocab_dir ../../data/\
    --mission 'train'\
    --lr 5e-5\
    --num_train_epochs 10\
    --fp16\
    --output_model_dir ../../data/output_model/aste/
