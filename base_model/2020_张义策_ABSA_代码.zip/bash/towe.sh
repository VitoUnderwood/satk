#!/bin/bash


while getopts ':d:t:m:' opt
do
    case $opt in
        d)
        dataset="$OPTARG" ;;
        t)
        model_type="$OPTARG" ;;
        m)
        mission="$OPTARG" ;;
        ?)
        echo "未知参数"
        exit 1;;
    esac
done

echo "dataset=$dataset, mission=$mission, model_type=$model_type"

python towe.py\
    --train_file_name towe/$dataset/train.json\
    --test_file_name towe/$dataset/test.json\
    --bert_model_dir ../../data/\
    --bert_vocab_dir ../../data/\
    --mission $mission\
    --model_type $model_type\
    --lr 3e-5\
    --fp16\
    --output_model_dir ../data/output_model/towe/$model_type/
