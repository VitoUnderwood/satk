此代码包含两部分代码：

1. towe：面向评价对象的评价词抽取
2. aste：观点三元组抽取

环境配置：

1. pytorch-1.5.0
2. transformer-2.5.1
3. apex: 可以尝试按照如下方式配置
	unzip apex.zip
	cd apex
	pip install --user -v --no-cache-dir ./
4. bert-base-uncase
	bert模型的地址需要和bash/towe.sh中的地址相匹配


代码运行：

towe训练：
	bash/towe.sh -d '16res' -t 'span' -m 'train'
	bash/towe.sh -d '16res' -t 'crf' -m 'train'
towe输出结果：
	bash/towe.sh -d '16res' -t 'span' -m 'output'
	结果举例：

句子:['not', 'the', 'biggest', 'portions', 'but', 'adequate', '.']中评价对象['portions']对应的观点评价词：
5 6 ['adequate']
0 3 ['not', 'the', 'biggest']
句子:['it', 'has', 'great', 'su', '##shi', 'and', 'even', 'better', 'service', '.']中评价对象['su', '##shi']对应的观点评价词：
2 3 ['great']
句子:['i', 'complained', 'to', 'the', 'manager', ',', 'but', 'he', 'was', 'not', 'even', 'apologetic', '.']中评价对象['manager']对应的观点评价词：
9 12 ['not', 'even', 'apologetic']

aste训练：
	bash/aste.sh -d '16res'