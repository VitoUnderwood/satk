from utils import get_device

from specific import BestPerformance
from specific.base_trainer import BaseTrainer
from specific.recorder import OpinionRecorder

import argparse
import torch
import math
# from tqdm import tqdm

from transformers.optimization import AdamW
import logging; logging.getLogger("transformers").setLevel(logging.WARNING)


class Trainer(BaseTrainer):
    def __init__(self, model, device, print_step,
                 output_model_dir, fp16, mode):

        super(Trainer, self).__init__(model, device, print_step, output_model_dir, fp16)
        self.mode = mode
        
        self.train_record = OpinionRecorder(mode=mode)
        self.valid_record = OpinionRecorder(mode=mode)
        self.best_performance = BestPerformance()

    def _prepare_batch(self, batch):
        if 'span' not in self.mode:
            idx, input_ids, attention_mask, token_type_ids, o_labels = batch
            batch = self.clip_batch(input_ids, attention_mask, token_type_ids,
                                    additional_inf=(o_labels, ), pad_idx=0)
        else:
            idx, input_ids, attention_mask, token_type_ids, s_labels, e_labels, n = batch
            batch = self.clip_batch(input_ids, attention_mask, token_type_ids,
                                    additional_inf=(s_labels, e_labels), pad_idx=0)
            batch += (n, )

        batch = tuple(t.to(self.device) for t in batch)
        
        return idx, batch

    def _forward(self, batch, record, p=0):
        idx, batch= self._prepare_batch(batch)
        if 'span' not in self.mode:
            loss, y_pred = self.model(*batch[:])
            with torch.no_grad():
                record.inc(loss, y_pred, batch[-1])
        else:
            loss, s, e, n = self.model(*batch[:])
            with torch.no_grad():
                record.inc(loss, s, e, n, batch[-3], batch[-2], batch[-1])

        return loss

    def _report(self, train_record, valid_record):
        tloss, tacc = train_record.report()
        vloss, vacc = valid_record.report()

        print(f'\n____Train: loss {tloss:.4f}, f1: {tacc:.4f}|'
              f' Test: loss {vloss:.4f} f1: {vacc:.4f}')

        return vacc

    def make_optimizer(self, weight_decay, lr):
        params = list(self.model.named_parameters())

        keywords = []

        def has_keywords(n):
            return any(nd in n for nd in keywords)

        parameters = [
            {'params': [p for n, p in params if has_keywords(n)], 'lr': lr},
            {'params': [p for n, p in params if not has_keywords(n)], 'lr': lr}
        ]

        optimizer = AdamW(parameters, eps=1e-8)
        return optimizer


class TOWE:
    """
    1. self.init()
    2. self.train(...)
    3. cls.load(...)
    """
    def __init__(self, config):
        self.config = config

    def init(self, ModelClass):
        gpu_ids = list(map(int, self.config.gpu_ids.split()))
        device = get_device(gpu_ids)

        print('init_model', self.config.bert_model_dir)

        model = ModelClass.from_pretrained(
            self.config.bert_model_dir,
            mode=self.config.model_type)

        self.trainer = Trainer(
            model, device,
            self.config.print_step,
            self.config.output_model_dir,
            self.config.fp16,
            mode=self.config.model_type)

    def train(self, train_dataloader, test_dataloader):
        self.trainer.set_t_total(train_dataloader, self.config.num_train_epochs)
        warmup_proportion = self.config.warmup_proportion

        self.trainer.set_optimizer_and_scheduler(self.config.weight_decay, self.config.lr, warmup_proportion)

        self.trainer.train(self.config.num_train_epochs, train_dataloader, test_dataloader)

    def output_result(self, sentence, target):
        from specific.feature import Feature
        from specific.tensor import convert_feature_to_tensor
        from specific.example import opinion_span as span
        
        tokens = tokenizer.tokenize(sentence)
        target_tokens = tokenizer.tokenize(target)

        feature = Feature.make_double(1, tokens, target_tokens, tokenizer, len(tokens) + len(target_tokens) + 3)
        features = [feature]
        _, input_ids, attention_mask, token_type_ids = convert_feature_to_tensor(features)

        start_logits, end_logits, n_pred = self.trainer.model.predict(
            input_ids.cuda(), attention_mask.cuda(), token_type_ids.cuda())
        
        y_pred = span.parse(start_logits[0].detach().cpu().numpy(), 
                            end_logits[0].detach().cpu().numpy(),
                            pn=n_pred[0].detach().cpu().numpy())
        opinion_words = []
        print(f'句子:{tokens}中评价对象{target_tokens}对应的观点评价词：')
        for s, e in y_pred:
            print(s-1,e-1, tokens[s-1:e-1])


def get_args():
    parser = argparse.ArgumentParser()

    # 训练过程中的参数
    parser.add_argument('--lr', type=float, default=3e-5)
    parser.add_argument('--batch_size', type=int, default=16)
    parser.add_argument('--num_train_epochs', type=int, default=5)
    parser.add_argument('--warmup_proportion', type=float, default=0.1)
    parser.add_argument('--weight_decay', type=float, default=0.)

    # 路径参数
    parser.add_argument('--train_file_name', type=str)
    parser.add_argument('--test_file_name', type=str)

    parser.add_argument('--output_model_dir', type=str)
    parser.add_argument('--bert_model_dir', type=str)
    parser.add_argument('--bert_vocab_dir', type=str)

    # 其他参数
    parser.add_argument('--print_step', type=int, default=100)
    parser.add_argument('--gpu_ids', type=str, default='0', help='以空格分割')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--mission', type=str, default='train')
    parser.add_argument('--max_seq_length', type=int, default=128)
    parser.add_argument('--fp16', action='store_true')
    parser.add_argument('--model_type', type=str, default='asc')

    args = parser.parse_args()
    return args


if __name__ == '__main__':
    from transformers.tokenization_bert import BertTokenizer as Tokenizer

    from specific.io import load_data
    from specific.tensor import make_dataloader
    from model.ote_model import TokenClassification
    from model.span_model import SpanExtraction
    from utils import set_seed

    args = get_args()
    assert args.mission in ('train', 'output')
    assert args.model_type in ('crf', 'span', 'gate-crf', 'gate-span')

    # 设置随机种子，保证模型的可复现性
    set_seed(args)

    # ------------------------------------------------#    
    print('load_vocab', args.bert_vocab_dir)
    tokenizer = Tokenizer.from_pretrained(args.bert_vocab_dir)
    
    if args.mission == 'train':
        print('load_data', args.train_file_name)
        train_data = load_data(args.train_file_name)

        print('load_data', args.test_file_name)
        test_data = load_data(args.test_file_name)

        dataloader_task = 'towe-span' if 'span' in args.model_type else 'towe'    

        test_dataloader = make_dataloader(
            dataloader_task, test_data, tokenizer,
            batch_size=args.batch_size,
            max_seq_length=args.max_seq_length,
            shuffle=False)

        print('test_data %d ' % len(test_data))

        train_dataloader = make_dataloader(
            dataloader_task, train_data, tokenizer,
            batch_size=args.batch_size,
            max_seq_length=args.max_seq_length)

        print('train_data %d ' % len(train_data))

    # -------------------- main ----------------------#
    if args.mission == 'train':
        srt = TOWE(args)
        if 'span' not in args.model_type:
            srt.init(TokenClassification)
        else:
            srt.init(SpanExtraction)
        srt.train(train_dataloader, test_dataloader)

    elif args.mission == 'output':
        srt = TOWE(args)
        if 'span' not in args.model_type:
            raise NotImplementedError()
        else:
            srt.config.bert_model_dir = srt.config.output_model_dir
            srt.init(SpanExtraction)

        sentence = "Not the biggest portions but adequate ."
        target = 'portions'
        srt.output_result(sentence, target)
        sentence = "It has great sushi and even better service ."
        target = 'sushi'
        srt.output_result(sentence, target)
        sentence = "I complained to the manager , but he was not even apologetic ."
        target = 'manager'
        while True:
            srt.output_result(sentence, target)
            sentence = input('sentence: ')
            if sentence == '':
                break
            target = input('target: ')
    # ------------------------------------------------#
