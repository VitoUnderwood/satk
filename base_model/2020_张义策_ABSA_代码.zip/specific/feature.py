class Feature:
	def __init__(self, idx, input_ids, input_mask, segment_ids):
		self.idx = idx
		self.input_ids = input_ids
		self.input_mask = input_mask
		self.segment_ids = segment_ids

	@classmethod
	def make_single(cls, idx, tokens, tokenizer, max_seq_length):
		tokens = ['[CLS]'] + tokens + ['[SEP]']

		assert len(tokens) <= max_seq_length

		input_ids = tokenizer.convert_tokens_to_ids(tokens)
		input_mask = [1] * len(input_ids)
		segment_ids = [0] * len(input_ids)

		padding = [0] * (max_seq_length - len(input_ids))

		input_ids += padding
		input_mask += padding
		segment_ids += padding

		return cls(idx, input_ids, input_mask, segment_ids)

	@classmethod
	def make_double(cls, idx, tokens1, tokens2, tokenizer, max_seq_length):
		tokens = ['[CLS]'] + tokens1 + ['[SEP]'] + tokens2 + ['[SEP]']

		assert len(tokens) <= max_seq_length
        
		input_ids = tokenizer.convert_tokens_to_ids(tokens)
		input_mask = [1] * len(input_ids)
		segment_ids = [0] * (len(tokens1) + 2) + [1] * (len(tokens2) + 1)

		padding = [0] * (max_seq_length - len(input_ids))

		input_ids += padding
		input_mask += padding
		segment_ids += padding

		return cls(idx, input_ids, input_mask, segment_ids)
