from specific import Vn
from specific.example import opinion_tagset, opinion_span
# target_polarity_tagset
# from specific.example import target_tagset as target_polarity_tagset
from specific.example import opinion_tagset as target_polarity_tagset

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


def cal_f1(y_preds, labels, tagset):

    record = Vn(3)

    for y_pred, y_true in zip(y_preds.cpu().numpy(), labels.cpu().numpy()):
        y_pred = tagset.parse_idx(y_pred)[0]
        y_true = tagset.parse_idx(y_true)[0]
        
        y_pred = [(t, s, e) for t, s, e in y_pred]
        y_true = [(t, s, e) for t, s, e in y_true]

        intersection = set(y_pred).intersection(y_true)
        
        # print(y_true)
        # print(y_pred)

        record.inc((len(intersection), len(y_true), len(y_pred)))

    return tuple(record.list())


def cal_span_f1(start_log, end_log, start_pos, end_pos, span, predicts):
    record = Vn(3)

    # first = True
    for s, e, sp, ep, pn in zip(start_log.cpu().numpy(),
                            end_log.cpu().numpy(),
                            start_pos.cpu().numpy(),
                            end_pos.cpu().numpy(),
                            predicts.cpu().numpy()):

        y_pred = span.parse(s,e, pn=pn)
        # y_pred = span.parse(s,e, logit_threshold=6)
        y_true = span.parse(sp, ep)
        intersection = set(y_pred).intersection(y_true)
        # if first:
        #     print('\n', intersection,'\t',y_true,'\t',y_pred)
        # first = False
        record.inc((len(intersection), len(y_true), len(y_pred)))
    
    return tuple(record.list())


class OpinionRecorder:
    def __init__(self, mode):
        self.record = Vn(4+2)
        self.mode = mode
    
    def init(self):
        self.record = Vn(4+2)
    
    # def inc(self, loss, pred, label):
    #     inc_nums = self._inc(pred, label)
    #     self.record.inc((loss.item(),) + inc_nums)
    
    def inc(self, loss, *args):
        if 'span' not in self.mode:
            inc_nums = self._inc(*args)
        else:
            f1, rn, an = self._span_inc(*args)
            inc_nums = f1 + (rn, an)

        self.record.inc((loss.item(),) + inc_nums)
        
    def _inc(self, pred, label):
        f1 = cal_f1(pred, label, target_polarity_tagset)
        return f1

    def _span_inc(self, start_log, end_log, pn, start_pos, end_pos, n):
        # predicts = torch.argmax(pn, dim=1) + 1
        predicts = pn
        # predicts = n
        right_num = torch.sum(predicts == n).item()
        # right_num = torch.sum((pn*5+0.5).type(torch.long)== n).item()
        all_num = n.size(0)

        f1 = cal_span_f1(start_log, end_log, start_pos, end_pos, opinion_span, predicts)

        return f1, right_num, all_num
    
    def report(self):
        loss = self.record[0].avg()

        tp, t, p, rn, an = self.record.list()[1:]
        f1 = 2 * tp / (t + p) if t != 0 else 0
        acc = rn / an if an != 0 else 0
        print(f'p:{tp/p:.4f}, r:{tp/t:.4f}, f:{f1:.4f}, acc={rn}/{an}={acc:.4f}')
        # print(f'acc={rn}/{an}={acc:.4f}')
        return loss, f1


class AsteRecorder:
    def __init__(self):
        # loss, t_f1*3, tp_f1*3, o_f1*3*2, pair*3, tri*3, p_f1*6, acc*4
        self.record = Vn(23+6)
    
    def init(self):
        self.record = Vn(23+6)

    def inc(self, loss, *args):
        t_f1, tp_f1, o_f1_1, o_f1_2, pair_f1, trip_f1, pp1_f1, pp2_f1, tp_rn, tp_an, op_rn, op_an = self._span_inc(*args)
        inc_nums = t_f1 + tp_f1 + o_f1_1 + o_f1_2 + pair_f1 + trip_f1 + pp1_f1 + pp2_f1 + (tp_rn, tp_an, op_rn, op_an)
        # print('\n', o_f1, self.record.list())
        self.record.inc((loss.item(),) + inc_nums)
    
    # ts, te, tp, tn, os, oe, op, on, tos, toe, ton
    def _span_inc(self, ts_pred, te_pred, tp_pred, tn_pred,
                        os_pred, oe_pred, op_pred, on_pred,
                        tos_pred, toe_pred, ton_pred,
                        ts_true, te_true, tp_true, tn_true,
                        os_true, oe_true, op_true, on_true,
                        tos_true, toe_true, ton_true):

        # tn_pred = torch.argmax(tn_pred, dim=-1)+1
        # tp_f1 = self.cal_span_f1(ts_pred, te_pred, ts_true, te_true, opinion_span, tn_pred, tp_pred, tp_true)
        
        tp_rn, tp_an = self.cal_polarity_acc(tp_pred, tp_true)
        op_rn, op_an = self.cal_polarity_acc(op_pred, op_true)

        ts_pred, te_pred, tp_pred, tn_pred,\
        os_pred, oe_pred, op_pred, on_pred,\
        ts_true, te_true, tp_true, tn_true,\
        os_true, oe_true, op_true, on_true,\
        tos_pred, toe_pred, ton_pred,\
        tos_true, toe_true, ton_true = [it.cpu().numpy() for it in (
            ts_pred, te_pred, tp_pred, tn_pred,
            os_pred, oe_pred, op_pred, on_pred,
            ts_true, te_true, tp_true, tn_true,
            os_true, oe_true, op_true, on_true,
            tos_pred, toe_pred, ton_pred,
            tos_true, toe_true, ton_true
        )]

   
        target_pred, target_polarity_pred, opinion_pred1, opinion_pred2, pair_pred, triple_pred, tp2_pred, tri2_pred = self.parse_opinion(
            ts_pred, te_pred, tp_pred, tn_pred,
            os_pred, oe_pred, op_pred, on_pred,
            tos_pred, toe_pred, ton_pred, pred_flag=True)

        target_true, target_polarity_true, opinion_true1, opinion_true2, pair_true, triple_true, tp2_true, tri2_true = self.parse_opinion(
            ts_true, te_true, tp_true, tn_true,
            os_true, oe_true, op_true, on_true,
            tos_true, toe_true, ton_true, pred_flag=False)

        t_f1 = self.f1_num(target_true, target_pred)
        tp_f1 = self.f1_num(target_polarity_true, target_polarity_pred)
        o_f1_1 = self.f1_num(opinion_true1, opinion_pred1)
        o_f1_2 = self.f1_num(opinion_true2, opinion_pred2)
        pair_f1 = self.f1_num(pair_true, pair_pred)
        triple_f1 = self.f1_num(triple_true, triple_pred)
        tp2_f1 = self.f1_num(tp2_true, tp2_pred)
        tri2_f1 = self.f1_num(tri2_true, tri2_pred)

        # print(o_f1_2)

        return t_f1, tp_f1, o_f1_1, o_f1_2, pair_f1, triple_f1, tp2_f1, tri2_f1, tp_rn, tp_an, op_rn, op_an

    def cal_span_f1(self, start_log, end_log, start_pos, end_pos, span, predicts, tp_pred, tp_true):
        target_pred = set()
        target_true = set()
        for i, (s, e, sp, ep, pn, tpp, tpt) in enumerate(zip(
                                start_log.cpu().numpy(),
                                end_log.cpu().numpy(),
                                start_pos.cpu().numpy(),
                                end_pos.cpu().numpy(),
                                predicts.cpu().numpy(),
                                tp_pred.cpu().numpy(),
                                tp_true.cpu().numpy(),
                                )):

            y_pred = span.parse(s,e, pn=pn)
            y_true = span.parse(sp, ep)
            
            for s, e in y_pred:
                polarity = tpp[s:e+1].max(axis=0).argmax()
                target_pred.add((i, polarity, s, e))

            for s, e in y_true:
                polarity = tpt[s]
                target_true.add((i, polarity, s, e))

            # target_pred.update([(i,s,e) for s,e in y_pred])
            # target_true.update([(i,s,e) for s,e in y_true])
        
        return self.f1_num(target_true, target_pred)

    def cal_polarity_acc(self, po_pred, po_true):
        loc = (po_true != -1)

        rn = torch.sum(torch.argmax(po_pred[loc], dim=-1) == po_true[loc])
        an = torch.sum(loc)
        return int(rn), int(an)
    
    def f1_num(self, true, pred):
        pred = set(pred)
        true = set(true)
        intersection = pred.intersection(true)
        
        return len(intersection), len(true), len(pred)

    def parse_opinion(self, ts_, te_, tp_, tn_,
                            os_, oe_, op_, on_,
                            tos_, toe_, ton_,
                            pred_flag=True):

        batch_size = ts_.shape[0]
        
        parsed_target = set()
        parsed_target_polarity = set()
        parsed_opinion1 = set()
        parsed_opinion2 = set()
        parsed_pair = set()
        parsed_triple = set()
        parsed_target_polarity2 = set()
        parsed_triple2 = set()

        tn_ = tn_.argmax(axis=-1)+1
        on_ = on_.argmax(axis=-1)+1

        for i in range(batch_size):

            if pred_flag is True:
                _target = opinion_span.parse(ts_[i], te_[i], pn=tn_[i])
                _opinion = opinion_span.parse(os_[i], oe_[i], pn=on_[i], overlap_loc=_target)
            else:
                _target = opinion_span.parse(ts_[i], te_[i])
                _opinion = opinion_span.parse(os_[i], oe_[i])

            for _ts, _te in _target:
                tosij = tos_[i][_ts:_te+1].max(axis=0) # [L]
                toeij = toe_[i][_ts:_te+1].max(axis=0) # [L]
                
                if pred_flag is True:
                    tonij = ton_[i][_ts:_te+1].max(axis=0) # [n]
                    tonij = tonij.argmax(axis=0) + 1
                    _opinion_2 = opinion_span.parse(
                        tosij, toeij, pn=tonij, overlap_loc=_target,)
                        # should_loc=_opinion)
                    # should in this loc
                    # ..............
                    # print(_opinion_2)
                else:
                    _opinion_2 = opinion_span.parse(tosij, toeij)

                if pred_flag is False:
                    polarity1 = polarity2 = tp_[i][_ts]  # 真实值
                    # polaritys = []

                    # polaritys.append(tp_pred[i][_ts:_te+1])
                    # _polaritys = np.concatenate(polaritys, axis=0)
                    # polarity1_pred = _polaritys.max(axis=0).argmax()  # 在target上的预测值

                    # for _os, _oe in _opinion:
                    #     polaritys.append(op_pred[i][_os:_oe+1])

                    # polaritys = np.concatenate(polaritys, axis=0)
                    # polarity2_pred = polaritys.max(axis=0).argmax()  # 综合target和opinion上倾向预测值

                else:
                    polaritys = []
                    polaritys.append(tp_[i][_ts:_te+1])

                    _polaritys = np.concatenate(polaritys, axis=0)
                    polarity1 = _polaritys.max(axis=0).argmax()
                    for _os, _oe in _opinion_2:
                        polaritys.append(op_[i][_os:_oe+1])

                    polaritys = np.concatenate(polaritys, axis=0)
                    polarity2 = polaritys.max(axis=0).argmax()

                parsed_target.add((i, _ts, _te))
                parsed_target_polarity.add((i, _ts, _te, polarity1))

                parsed_opinion1.update([(i,_os,_oe) for _os,_oe in _opinion])
                parsed_opinion2.update([(i,_os,_oe) for _os,_oe in _opinion_2])
                parsed_pair.update([(i,_ts,_te,_os,_oe) for _os,_oe in _opinion_2])
                parsed_triple.update([(i,_ts,_te,_os,_oe,polarity1) for _os,_oe in _opinion_2])
                
                parsed_target_polarity2.add((i, _ts, _te, polarity2))
                parsed_triple2.update([(i,_ts,_te,_os,_oe,polarity2) for _os,_oe in _opinion_2])

        
        return parsed_target, parsed_target_polarity, parsed_opinion1, parsed_opinion2, parsed_pair, parsed_triple, parsed_target_polarity2, parsed_triple2
        
    def _f1(self, tp, t, p):
        _p = tp / p if p != 0 else 0
        _r = tp / t if t != 0 else 0
        f1 = 2 * tp / (t + p) if t != 0 else 0
        return _p, _r, f1

    def report(self):
        # loss, t_f1*3, tp_f1*3, o_f1*3*2, pair*3, tri*3, acc*4
        loss = self.record[0].avg()

        t_f1 = self.record.list()[1:4]
        tp_f1 = self.record.list()[4:7]
        o_f1_1 = self.record.list()[7:10]
        o_f1_2 = self.record.list()[10:13]
        pair_f1 = self.record.list()[13:16]
        trip_f1 = self.record.list()[16:19]
        tp2_f1 = self.record.list()[19:22]
        tri2_f1 = self.record.list()[22:25]
        rn1, an1, rn2, an2 = self.record.list()[19+6:23+6]

        t_prf = self._f1(*t_f1)
        tp_prf = self._f1(*tp_f1)
        o_prf_1 = self._f1(*o_f1_1)
        o_prf_2 = self._f1(*o_f1_2)
        pair_prf = self._f1(*pair_f1)
        trip_prf = self._f1(*trip_f1)
        tp2_prf = self._f1(*tp2_f1)
        tri2_prf = self._f1(*tri2_f1)

        print(f'tf1 \tp:{t_prf[0]:.4f}, r:{t_prf[1]:.4f}, f:{t_prf[2]:.4f}', t_f1)
        print(f'tpf1\tp:{tp_prf[0]:.4f}, r:{tp_prf[1]:.4f}, f:{tp_prf[2]:.4f}', tp_f1)

        print(f'of1_1\tp:{o_prf_1[0]:.4f}, r:{o_prf_1[1]:.4f}, f:{o_prf_1[2]:.4f}', o_f1_1)
        print(f'of1_2\tp:{o_prf_2[0]:.4f}, r:{o_prf_2[1]:.4f}, f:{o_prf_2[2]:.4f}', o_f1_2)
        print(f'pair\tp:{pair_prf[0]:.4f}, r:{pair_prf[1]:.4f}, f:{pair_prf[2]:.4f}', pair_f1)
        print(f'trip\tp:{trip_prf[0]:.4f}, r:{trip_prf[1]:.4f}, f:{trip_prf[2]:.4f}', trip_f1)
        print(f'tp2 \tp:{tp2_prf[0]:.4f}, r:{tp2_prf[1]:.4f}, f:{tp2_prf[2]:.4f}', tp2_f1)
        print(f'tri2\tp:{tri2_prf[0]:.4f}, r:{tri2_prf[1]:.4f}, f:{tri2_prf[2]:.4f}', tri2_f1)

        print(f'pola\tacc:{rn1}/{an1}={rn1/an1:.4f}')
        print(f'pola\tacc:{rn2}/{an2}={rn2/an2:.4f}')

        return loss, t_prf[2]


class AscRecorder:
    def __init__(self):
        self.record = Vn(3)
    
    def init(self):
        self.record = Vn(3+3)
    
    def inc(self, loss, logit, label):
        inc_nums = self._inc(logit, label)
        self.record.inc((loss.item(),) + inc_nums)
    
    def _inc(self, logits, labels):
        logits = F.softmax(logits, dim=1)
        predicts = torch.argmax(logits, dim=1)

        right_num = torch.sum(predicts==labels).item()
        return right_num, logits.size(0)
    
    def report(self):
        loss = self.record[0].avg()

        rn, an = self.record.list()[1:3]
        acc = rn / an if an != 0 else 0
        print(rn, an)
        # tp, t, p = self.record.list()[3:]
        # f1 = 2 * tp / (t + p) if t != 0 else 0
        return loss, acc
    

class PostTrainRecorder:
    def __init__(self):
        self.record = Vn(1)
    
    def init(self):
        self.record = Vn(1)
    
    def inc(self, loss):
        self.record.inc((loss.item(),))
    
    def report(self):
        return self.record[0].avg()


class AttRecorder:
    def __init__(self, tokenizer):
        """
        att: Layer*head(12*12=144)
             OTN=>OTN(9)
        """
        self.vn = 144 * 9 * 2
        self.record = Vn(self.vn)
        self.final_contribution = Vn(18)
        self.tokenizer = tokenizer

    def update(self, attentions, entity_labels, input_ids):
        """
        attention: [12, [B,H,L,L]]
        entity_labels: [B, L]
        """
        
        sums, nums = [0 for _ in range(9)], [0 for _ in range(9)]
        for i, sum_, num in self.iter_cal_fc(attentions, entity_labels, input_ids):
            sums[i] = sum_
            nums[i] = num
        self.final_contribution.inc(sums + nums)

        sums, nums = [], []

        entity_labels = entity_labels.cpu().numpy()
        for layer_index, layer_attention in enumerate(attentions):
            layer_attention = layer_attention.cpu().numpy()
            for head_index in range(12):
                attention = layer_attention[:, head_index]
                _sums = [0 for _ in range(9)]
                _nums = [0 for _ in range(9)]
                for i, sum_, num in self.parse(attention, entity_labels):
                    _sums[i] = sum_
                    _nums[i] = num
                sums.extend(_sums)
                nums.extend(_nums)
        self.record.inc(sums + nums)

    def print_scores(self, prom, nine, div=1):
        print(prom, end='\t')
        for it in nine:
            print(f'{(it-nine[-1])/div:.4f}', end="\t")
        print()

    def print_scores_2(self, prom, lst, div=1):
        print(prom, end='\t')
        for it in lst:
            print(f'{it/div:.4f}', end="\t")
        print()

    def report(self):
        print('type', end='\t')
        for start in 'OTN':
            for end in 'OTN':
                print(f'{start}->{end}', end='\t')
        print()

        head_avg_o_t = [0 for _ in range(12)]
        layer_avg_o_t = [0 for _ in range(12)]

        record_list = self.record.list()
        model_avg = [0 for _ in range(9)]
        for layer_index in range(12):
            print(f'--------layer{layer_index}-------')
            layer_avg = [0 for _ in range(9)]
            for head_index in range(12):
                head_avg = [0 for _ in range(9)]

                for i in range(9):
                    idx1 = layer_index * 12 * 9 + head_index * 9 + i
                    idx2 = idx1 + 12 * 12 * 9
                    sum_ = record_list[idx1]
                    num = record_list[idx2]
                    avg = sum_/num if num else 0

                    head_avg[i] += avg
                    layer_avg[i] += avg
                    model_avg[i] += avg
                
                head_avg_o_t[head_index] += head_avg[1] - head_avg[-1]
                
                self.print_scores(f'head{head_index}:', head_avg)

            layer_avg_o_t[layer_index] += layer_avg[1] - layer_avg[-1]
            self.print_scores('layer_avg:', layer_avg, 12)

        self.print_scores('model_avg:', model_avg, 12*12)
        print()
        self.print_scores_2('head:', head_avg_o_t, 12)
        self.print_scores_2('layer:', layer_avg_o_t, 12)
        print()
        print('Final_contribution:', end=' ')
        record_list = self.final_contribution.list()
        print(record_list)
        for i in range(9):
            idx1 = i
            idx2 = i + 9
            sum_ = record_list[idx1]
            num = record_list[idx2]
            print(sum_/num)

    def type_iterator(self):
        for index1, type1 in (
            (0, 'B-opinion'),
            (0, 'I-opinion'),
            (1, 'B-target'),
            (1, 'I-target'),
            (2, 'O'),
            # (2, 'SOS'),
        ):
            for index2, type2 in (
                (0, 'B-opinion'),
                (0, 'I-opinion'),
                (1, 'B-target'),
                (1, 'I-target'),
                (2, 'O'),
                # (2, 'SOS'),
            ):
                yield index1 * 3 + index2, entity_tagset[type1], entity_tagset[type2]

    def index_by_type(self, type1, type2, entity_labels):
        return (entity_labels == type1)[:, np.newaxis, :] * (entity_labels == type2)[:, :, np.newaxis]

    def parse(self, attention, entity_labels):
        """
        attention: [B, L, L]
        entity_labels: [B, L]
        yield: i, sum, num
        """
        L = attention.shape[1]
        for (i, type1, type2) in self.type_iterator():
            index = self.index_by_type(type1, type2, entity_labels)
            index[:, range(L), range(L)] = False
            type_attention = attention[index]
            score_sum = sum(type_attention)
            score_num = len(type_attention)
            yield i, score_sum, score_num

    def iter_cal_fc(self, attention, entity_labels, input_ids):
        """
        attention: [12, [B,H,L,L]]
        entity_labels: [B, L]
        """
        L = attention[0].size(-1)
        
        tokens = self.tokenizer.convert_ids_to_tokens(input_ids[0])
        tokens = [token for token in tokens if token != '[PAD]']
        
        B_target = (entity_labels == entity_tagset['B-target'])
        I_target = (entity_labels == entity_tagset['I-target'])
        is_target = (B_target + I_target).type(torch.float)

        print_flag = (12 <= len(tokens) <= 15) and (is_target[0].sum() == 1)

        # [B, L, L]
        FC = torch.zeros_like(attention[0][:, 0])
        FC[:, range(L), range(L)] = 1
        
        print()
        if print_flag:
            print(tokens)
        #     self.case_print(entity_labels, tokens, FC)

        for layer_attention in attention:
            layer_attention = nn.Softmax(dim=-1)(layer_attention)
            layer_attention = layer_attention.mean(1)  # [B, L, L]
            
            if print_flag:
                # self.case_print(entity_labels, tokens, FC)
                self.case_print(entity_labels, tokens, layer_attention)

            layer_attention[:, range(L), range(L)] += 1
            layer_attention = layer_attention / 2 

            FC = FC.bmm(layer_attention)
            # if print_flag:
                # self.case_print(entity_labels, tokens, FC)
                # self.case_print(entity_labels, tokens, layer_attention)

        # [B, L, L]
        res = []
        for (i, type1, type2) in self.type_iterator():
            # if i not in (1, 3, 7):
            #     continue
            index = self.index_by_type(type1, type2, entity_labels)
    
            type_fc = FC[index]
            score_sum = sum(type_fc)
            score_num = len(type_fc)

            yield i, float(score_sum), float(score_num)
    
    def case_print(self, entity_labels, tokens, FC):
        # for index, tag in enumerate(entity_labels[0]): # [L]
        #     if tag in (entity_tagset['B-target'], entity_tagset['I-target']):
        #         print(tokens[index], end=': ')
        #         for token, score in zip(tokens, FC[0][index]):
        #             if token == '[PAD]': break
        #             print('%s%4d' % (token, score*10000), end="_")
        #         print()

        for index, tag in enumerate(entity_labels[0]): # [L]
            if tag in (entity_tagset['B-target'], entity_tagset['I-target']):
                print(f'{tokens[index]} [', end='')
                for token, score in zip(tokens, FC[0][index]):
                    print('%.4f' % score, end=", ")
                print('],')



class Recorder:
    def __init__(self):
        """
        loss: 2
        Acc:  2
        F1:   6
        """
        self.vn = 10
        self.record = Vn(self.vn)
        self.idx_set = set()

    def init(self):
        self.record.init()
        self.idx_set = set()

    def item(self, it):
        if type(it) is int:
            return it
        else:
            return it.item()

    def inc(self, idx, loss, pred, label):
        inc_nums = self._inc(idx, pred, label)

        loss = tuple(self.item(loss[key]) for key in ('asc', 'opinion'))
        self.record.inc(loss + inc_nums)

    def _inc(self, idx, pred, label):
        opinion_labels, target_labels, absa_labels = label

        cnp = lambda it: it.cpu().numpy()

        acc = self.Acc(pred['asc'], absa_labels)

        f1 = self.F1(idx, pred['opinion'], opinion_labels)
        return acc + f1

    def report(self):

        loss1 = self.record[0].avg()
        loss2 = self.record[1].avg()

        rn1, an1 = self.record.list()[2:4]
        acc = rn1 / an1 if an1 != 0 else 0
        print(rn1, an1)

        tp1, t1, p1, tp2, t2, p2 = self.record.list()[4:10]
        f1 = 2 * tp2 / (t2 + p2) if t2 != 0 else 0
        # print(tp1, t1, p1, tp2, t2, p2)
        return loss1, loss2, acc, f1

    def Acc(self, logits, labels):
        if logits is not None:
            active_loc = (labels != -1)
            labels = labels[active_loc]

            logits = F.softmax(logits, dim=1)
            predicts = torch.argmax(logits, dim=1)
            right_num = torch.sum(predicts==labels).item()
            return right_num, logits.size(0)
        else:
            return 1, 1

    def F1(self, idx, y_preds, labels):
        if y_preds is not None:
            record = Vn(6)

            for _idx, y_pred, y_true in zip(idx.numpy(), y_preds.cpu().numpy(), labels.cpu().numpy()):

                if _idx not in self.idx_set:
                    self.idx_set.add(_idx)
                    y_pred = opinion_tagset.parse_idx(y_pred)[0]
                    y_true = opinion_tagset.parse_idx(y_true)[0]
                    record.inc(self._f1(y_pred, y_true))

            return tuple(record.list())

        else:
            return (1,) * 6

    def _f1(self, y_pred, y_true):
        a_pred = [it for it in y_pred if it[0] == 'target']
        a_true = [it for it in y_true if it[0] == 'target']

        o_pred = [it for it in y_pred if it[0] == 'opinion']
        o_true = [it for it in y_true if it[0] == 'opinion']

        a_intersection = set(a_pred).intersection(a_true)
        o_intersection = set(o_pred).intersection(o_true)

        return (len(a_intersection), len(a_true), len(a_pred),
                len(o_intersection), len(o_true), len(o_pred))
