from utils import Vn, get_device
from utils import mkdir_if_notexist
from . import BestPerformance

import torch
from transformers.optimization import AdamW
from transformers.optimization import get_cosine_with_hard_restarts_schedule_with_warmup, get_linear_schedule_with_warmup
# from transformers.file_utils import WEIGHTS_NAME, CONFIG_NAME

from tqdm.autonotebook import tqdm

try:
    from apex import amp
except ImportError:
    print('apex not imported')


class BaseTrainer:
    """
    训练模型的基本流程
    """
    def __init__(self, model, device, print_step, output_model_dir, fp16, vn=2):
        """
        device: 主device
        multi_gpu: 是否使用了多个gpu
        vn: 显示的变量数
        """
        self.fp16 = fp16
        self.model = model.to(device)
        self.device = device
        self.print_step = print_step
        self.output_model_dir = output_model_dir

        self.global_step = 0

        self.train_record = Vn(vn)
        self.valid_record = Vn(vn)
        self.best_performance = BestPerformance()

    def set_optimizer_and_scheduler(self, weight_decay, lr, warmup_proportion, schr='cosh'):
        optimizer = self.make_optimizer(weight_decay, lr)
        if schr == 'cosh':
            scheduler = self.make_coshs_scheduler(optimizer, warmup_proportion, self.t_total)
        elif schr == 'linear':
            scheduler = self.make_linear_scheduler(optimizer, warmup_proportion, self.t_total)

        if self.fp16:
            model, optimizer = amp.initialize(self.model, optimizer, opt_level='O1')
            self.model = model

        self.optimizer = optimizer
        self.scheduler = scheduler

    def set_t_total(self, train_dataloader, epoch_num):
        self.t_total = len(train_dataloader) * epoch_num

    def train(self, epoch_num, train_dataloader, valid_dataloader):
        self.best_performance.init()

        self.global_step = 0
        self.train_record.init()
        self.model.zero_grad()

        for epoch in range(int(epoch_num)):
            print(f'---- Epoch: {epoch+1:02} ----')
            self._train_single_epoch(train_dataloader, valid_dataloader)

        self.report_on_train_valid(self.train_record, valid_dataloader)

        print(self.best_performance.report())
        print('train finished....')

    def _train_single_epoch(self, train_dataloader, valid_dataloader):
        for step, batch in enumerate(tqdm(train_dataloader, desc='')):
            torch.cuda.empty_cache()
            self.model.train()
            self._step(batch, self.global_step/self.t_total)

            if self.global_step % self.print_step == 0:
                performance = self.report_on_train_valid(self.train_record, valid_dataloader)
                self.save_model_at_best_performance(performance)

                self.train_record.init()

        print(self.best_performance.report())

    def report_on_train_valid(self, train_record, valid_dataloader):
        test_record = self.evaluate(valid_dataloader)
        performance = self._report(self.train_record, test_record)
        self.best_performance.update((performance, ))
        return performance

    def save_model_at_best_performance(self, performance):
        if self.best_performance.values[0] <= performance:
            self.save_model()

    def _report(self, train_record, valid_record):
        # 需要重写
        tloss = train_record.report()
        vloss = valid_record.report()

        print(f'\n____Train: loss {tloss:.4f}, Test: loss {vloss:.4f}')

        return vloss

    def _forward(self, batch, record, p=0):
        # 需要重写
        idx, batch = self._prepare_batch(batch)
        loss = self.model(*batch)

        with torch.no_grad():
            record.inc(loss)
        return loss

    def _prepare_batch(self):
        # 需要重写
        pass

    def clip_batch(self, input_ids, attention_mask, token_type_ids=None, additional_inf=(), pad_idx=0):
        input_ids, max_seq_length, input_dim = self._clip_input_ids(input_ids, pad_idx)

        if attention_mask.dim() == input_dim:
            attention_mask = attention_mask[..., :max_seq_length]

        elif attention_mask.dim() == input_dim + 1:
            attention_mask = attention_mask[..., :max_seq_length, :max_seq_length]

        result = (input_ids, attention_mask)

        if token_type_ids is not None:
            token_type_ids = token_type_ids[..., :max_seq_length]
            result += (token_type_ids,)

        if type(additional_inf) is not tuple:
            additional_inf = (additional_inf,)

        for i in range(len(additional_inf)):
            result += (additional_inf[i][..., :max_seq_length],)

        return result

    def _clip_input_ids(self, input_ids, pad_idx):
        batch_size = input_ids.size(0)
        n_tensor = input_ids.size(1)

        while True:
            for i in range(batch_size):
                if input_ids.dim() == 2:
                    if input_ids[i, -1] != pad_idx:
                        return input_ids, input_ids.size(-1), input_ids.dim()

                elif input_ids.dim() == 3:
                    for j in range(n_tensor):
                        if input_ids[i, j, -1] != pad_idx:
                            return input_ids, input_ids.size(-1), input_ids.dim()

                else:
                    raise NotImplementedError()

            input_ids = input_ids[..., :-1]

    def _backward(self, loss, retain_graph=False):
        if self.fp16:
            with amp.scale_loss(loss, self.optimizer) as scaled_loss:
                scaled_loss.backward(retain_graph=retain_graph)

            torch.nn.utils.clip_grad_norm_(amp.master_params(self.optimizer), 1)

        else:
            loss.backward(retain_graph=retain_graph)
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1)

    def _step(self, batch, p):
        loss = self._forward(batch, self.train_record, p)
        self._backward(loss)

        self.optimizer.step()
        self.scheduler.step()
        self.model.zero_grad()

        self.global_step += 1

    def evaluate(self, dataloader, desc='Eval'):
        self.valid_record.init()

        for batch in dataloader:
            self.model.eval()
            with torch.no_grad():
                self._forward(batch, self.valid_record)

        return self.valid_record

    def make_optimizer(self, weight_decay, lr):
        params = list(self.model.named_parameters())

        no_decay_keywords = ['bias', 'LayerNorm.weight']

        def _no_decay(n):
            return any(nd in n for nd in no_decay_keywords)

        parameters = [
            {'params': [p for n, p in params if _no_decay(n)], 'weight_decay': 0.0},
            {'params': [p for n, p in params if not _no_decay(n)],
             'weight_decay': weight_decay}
        ]

        optimizer = AdamW(parameters, lr=lr, eps=1e-8)
        return optimizer

    def make_coshs_scheduler(self, optimizer, warmup_proportion, t_total):
        return get_cosine_with_hard_restarts_schedule_with_warmup(
          optimizer, num_warmup_steps=warmup_proportion * t_total,
          num_training_steps=t_total)

    def make_linear_scheduler(self, optimizer, warmup_proportion, t_total):
        return get_linear_schedule_with_warmup(
          optimizer, num_warmup_steps=warmup_proportion * t_total,
          num_training_steps=t_total)

    def save_model(self):
        mkdir_if_notexist(self.output_model_dir)
        print('保存模型', self.output_model_dir)
        self.model.save_pretrained(self.output_model_dir)

    @classmethod
    def load_model(cls, ModelClass, config):
        gpu_ids = list(map(int, config.gpu_ids.split()))
        device = get_device(gpu_ids)

        model = ModelClass.from_pretrained(config.output_model_dir)
        model.to(device)

        return cls(model, device, config.print_step,
                   config.output_model_dir, config.fp16)
