from .feature import Feature
from utils.bio import Tagset
from utils.span import Span


entity_tagset = Tagset(['PAD', 'B-target', 'I-target', 'B-opinion', 'I-opinion', 'O', 'SOS', 'opinion'])
target_tagset = Tagset(['PAD', 'B-target', 'I-target', 'O', 'SOS'])
target_polarity_tagset = Tagset(['PAD', 'B-POS', 'I-POS', 'B-NEG', 'I-NEG', 'B-NEU', 'I-NEU', 'O', 'SOS'])
opinion_tagset = Tagset(['PAD', 'B-opinion', 'I-opinion', 'O', 'SOS'])
opinion_polarity_tagset = Tagset(['PAD', 'B-POS', 'I-POS', 'B-NEG', 'I-NEG', 'B-NEU', 'I-NEU', 'O', 'SOS'])

opinion_span = Span(n_best_size=13, max_span_length=20, top_K=13)


class Example:
    """
    1. cls.load_from_json()
    2. TODO: self.target_fl()
    3. self.entity_fl()
    4. self.target_polarity_fl()
    """
    polarity_map = {'POS': 0, 'NEU': 1, 'NEG': 2}
    def __init__(self, idx, sentence, opinion=[], target_polarity=[], aste=[]):
        try:
            self.idx = int(idx)
        except ValueError:
            self.idx = 1
        self.sentence = sentence.lower()
        self.opinion = opinion
        self.target_polarity = target_polarity
        self.aste = aste

    @classmethod
    def load_from_json(cls, json_obj):
        return cls(
            json_obj['ID'],
            json_obj['Sentence'],
            json_obj['Opinion'],
            json_obj['Target'],
        )

    @classmethod
    def load_from_json_aste(cls, json_obj):
        return cls(
            json_obj['ID'],
            json_obj['Sentence'],
            aste=json_obj['entities']
        )

    def opinion_fl(self, max_seq_length, tokenizer):
        tokens = tokenizer.tokenize(self.sentence)
        opinion = [('opinion', s+1, e+1, w) for s, e, w in self.opinion]

        opinion_entities = sorted(opinion, reverse=True, key=lambda it: it[1])
        opinion_tag_seq = opinion_tagset.make_bio_idx(opinion_entities, tokens, self.sentence, max_seq_length)

        parse_entity = opinion_tagset.parse_idx(opinion_tag_seq)[0]
        assert len(opinion) == len(parse_entity)

        feature = Feature.make_single(self.idx, tokens, tokenizer, max_seq_length)

        return feature, opinion_tag_seq

    def towe_fl(self, max_seq_length, tokenizer):
        tokens = tokenizer.tokenize(self.sentence)
        opinion = [('opinion', s+1, e+1, w) for s, e, w in self.opinion]

        opinion_entities = sorted(opinion, reverse=True, key=lambda it: it[1])
        opinion_tag_seq = opinion_tagset.make_bio_idx(opinion_entities, tokens, self.sentence, max_seq_length)

        parse_entity = opinion_tagset.parse_idx(opinion_tag_seq)[0]
        assert len(opinion) == len(parse_entity)

        target_tokens = tokenizer.tokenize(self.target_polarity[0][-1])
        feature = Feature.make_double(self.idx, tokens, target_tokens, tokenizer, max_seq_length)    

        return feature, opinion_tag_seq

    def ote_crf_fl(self, task, max_seq_length, tokenizer):
        tokens = tokenizer.tokenize(self.sentence)
        feature = Feature.make_single(self.idx, tokens, tokenizer, max_seq_length)

        if task == 'opinion-crf':
            opinion = []
            for triple in self.aste:
                for s, e, w in triple['opinions']:
                    opinion.append(('opinion', s+1, e+1, w))

            opinion_entities = sorted(opinion, reverse=True, key=lambda it: it[1])
            opinion_tag_seq = opinion_tagset.make_bio_idx(opinion_entities, tokens, self.sentence, max_seq_length)

            parse_entity = opinion_tagset.parse_idx(opinion_tag_seq)[0]
            assert len(opinion) == len(parse_entity)
            return feature, opinion_tag_seq

        elif task == 'target-crf':
            target = []
            for triple in self.aste:
                s, e, w = triple['target']
                polarity = triple['polarity']
                target.append((polarity, s+1, e+1, w))

            target_entities = sorted(target, reverse=True, key=lambda it: it[1])
            target_tag_seq = target_polarity_tagset.make_bio_idx(target_entities, tokens, self.sentence, max_seq_length)

            parse_entity = target_polarity_tagset.parse_idx(target_tag_seq)[0]
            assert len(target) == len(parse_entity)
            return feature, target_tag_seq

    def towe_span_fl(self, max_seq_length, tokenizer):
        tokens = tokenizer.tokenize(self.sentence)
        opinion = [('opinion', s+1, e+1, w) for s, e, w in self.opinion]

        opinion_entities = sorted(opinion, reverse=True, key=lambda it: it[1])
        opinion_tag_seq = opinion_tagset.make_bio_idx(opinion_entities, tokens, self.sentence, max_seq_length)

        parse_entity = opinion_tagset.parse_idx(opinion_tag_seq)[0]
        assert len(opinion) == len(parse_entity)

        entities = [(s, e) for _, s, e in parse_entity]
        start_positions, end_positions = opinion_span.make(entities, max_seq_length)

        parse_entity = opinion_span.parse(start_positions, end_positions)
        assert set(entities) == set(parse_entity), f'{entities} != {parse_entity}'

        target_tokens = tokenizer.tokenize(self.target_polarity[0][-1])
        feature = Feature.make_double(self.idx, tokens, target_tokens, tokenizer, max_seq_length)    

        return feature, start_positions, end_positions, len(entities)

    def aste_span_fl(self, max_seq_length, tokenizer):
        """
        return: feature
            TS, TE: [L]
            TN: int
            OS, OE: [L]
            ON: int
            TP, OP: [L]
            TOS, TOE: [L, L]
            TON: [L]
        """
        tokens = tokenizer.tokenize(self.sentence)

        TS, TE, TP, TN, OS, OE, OP, ON = self.make_target_opinion_span(tokens, max_seq_length)
        TOS, TOE, TON = self.make_opinion_span_matrix(tokens, max_seq_length)

        feature = Feature.make_single(self.idx, tokens, tokenizer, max_seq_length)
        return feature, TS, TE, TP, TN, OS, OE, OP, ON, TOS, TOE, TON

    def make_target_opinion_span(self, tokens, max_seq_length):
        target = []
        opinion = []
        for tri in self.aste:
            polarity = tri['polarity']
            ts, te, tw = tri['target']
            target.append((polarity, ts+1, te+1, tw))
            opinion.extend([(polarity, os+1, oe+1, ow)
                            for (os, oe, ow) in tri['opinions']])

        TS, TE, TP, TN = self._make_span(target, tokens, max_seq_length, target_polarity_tagset)
        OS, OE, OP, ON = self._make_span(opinion, tokens, max_seq_length, opinion_polarity_tagset)

        return TS, TE, TP, TN, OS, OE, OP, ON

    def make_opinion_span_matrix(self, tokens, max_seq_length):
        TOS = [[0 for _ in range(max_seq_length)] for _ in range(max_seq_length)]
        TOE = [[0 for _ in range(max_seq_length)] for _ in range(max_seq_length)]
        TON = [0 for _ in range(max_seq_length)]

        for tri in self.aste:
            ts, te, tw = tri['target']
            polarity = tri['polarity']
            target = [('target', ts+1, te+1, tw)]

            target_entities = sorted(target, reverse=True, key=lambda it: it[1])
            target_tag_seq = target_tagset.make_bio_idx(
                target_entities, tokens, self.sentence, max_seq_length)

            parse_entity = target_tagset.parse_idx(target_tag_seq)[0]
            assert len(target) == len(parse_entity)

            opinion = [(polarity, os+1, oe+1, ow) for os, oe, ow in tri['opinions']]

            os, oe, _, on = self._make_span(opinion, tokens, max_seq_length, opinion_polarity_tagset)

            for i in range(parse_entity[0][1], parse_entity[0][2]):
                TOS[i] = os
                TOE[i] = oe
                TON[i] = on

        return TOS, TOE, TON

    def _make_span(self, entities, tokens, max_seq_length, tagset):
        len_entities = len(entities)
        entities = sorted(entities, reverse=True, key=lambda it: it[1])
        tag_seq = tagset.make_bio_idx(entities, tokens, self.sentence, max_seq_length)

        parse_entities = tagset.parse_idx(tag_seq)[0]
        assert len_entities == len(parse_entities), f'{len_entities}!=len({parse_entities})'

        polarity_seq = [-1 for _ in range(max_seq_length)]
        for po, s, e in parse_entities:
            for i in range(s, e):
                polarity_seq[i] = self.polarity_map[po]

        entities = [(s, e) for _, s, e in parse_entities]
        start_positions, end_positions = opinion_span.make(entities, max_seq_length)

        parse_entities = opinion_span.parse(start_positions, end_positions)

        # if len(set(entities)) != 13:
        assert set(entities) == set(parse_entities), f'{entities} != {parse_entities}'

        return start_positions, end_positions, polarity_seq, len(entities)

    def asco_opinion_fl(self, max_seq_length, tokenizer, task='asc'):
        assert task in ('asc', 'asco', 'bert-pair', 'bert-segment')

        tokens = tokenizer.tokenize(self.sentence)

        # parse_entity = opinion_tagset.parse_idx(opinion_tag_seq)[0]
        # assert len(opinion) == len(parse_entity)

        if task in ('asc',):
            feature = Feature.make_single(self.idx, tokens, tokenizer, max_seq_length)

        elif task in ('bert-pair', 'asco'):
            opinion = [('opinion', s+1, e+1, w) for s, e, w in self.opinion]
            if opinion:
                opinion_tokens = tokenizer.tokenize(opinion[0][-1])
                for item in opinion[1:]:
                    opinion_tokens.extend(tokenizer.tokenize(item[-1]))
            else:
                opinion_tokens = []
            feature = Feature.make_double(self.idx, tokens, opinion_tokens, tokenizer, max_seq_length)
            # else:
            #     feature = Feature.make_single(self.idx, tokens, tokenizer, max_seq_length)

        elif task == 'bert-segment':
            opinion = [('opinion', s+1, e+1, w) for s, e, w in self.opinion]
            opinion_entities = sorted(opinion, reverse=True, key=lambda it: it[1])
            opinion_tag_seq = opinion_tagset.make_bio_idx(opinion_entities, tokens, self.sentence, max_seq_length)

            feature = Feature.make_single(self.idx, tokens, tokenizer, max_seq_length)
            feature.segment_ids = [int(tag in (opinion_tagset['B-opinion'], opinion_tagset['I-opinion']))
                                   for tag in opinion_tag_seq]

        for tp in self.target_polarity:

            target_entity = [('target', tp[0]+1, tp[1]+1, tp[2])]
            target_tag_seq = target_tagset.make_bio_idx(target_entity, tokens, self.sentence, max_seq_length)
            opinion = [('opinion', s+1, e+1, w) for s, e, w in self.opinion]

            target_entity = [('target', tp[0]+1, tp[1]+1, tp[2])]
            entities = sorted(opinion+target_entity, reverse=True, key=lambda it: it[1])
            # try:
            entity_tag_seq = entity_tagset.make_bio_idx(entities, tokens, self.sentence, max_seq_length)

            if task == 'asco':
                # print(feature.input_ids)
                for i in range(max_seq_length):
                    if (entity_tag_seq[i] == 0 and feature.input_ids[i] not in (0, 102, 1010, 1001)):
                        entity_tag_seq[i] = entity_tagset['opinion']

            # except AssertionError:
                # print(target_entity + opinion)

            # 1: pos, 2: neg, 3: neu, 4: com
            asc_label = int(tp[3])-1
            if asc_label != 3:
                # yield feature, target_tag_seq, opinion_tag_seq, asc_label
                yield feature, target_tag_seq, entity_tag_seq, asc_label
