from utils import Vn as _Vn
from utils import AvgVar


class Vn(_Vn):
    """
    维护n个累加求平均的变量
    """
    def __init__(self, n):
        super(_Vn, self).__init__()

        self.n = n
        self.vs = [AvgVar() for i in range(n)]
        self.idx_set = set()

    def __getitem__(self, key):
        return self.vs[key]

    def init(self):
        self.vs = [AvgVar() for i in range(self.n)]
        self.idx_set = set()

    def inc(self, vs):
        for v, _v in zip(self.vs, vs):
            v.inc(_v)

    def avg(self):
        return [v.avg() for v in self.vs]

    def list(self):
        return [v.var for v in self.vs]


class BestPerformance:
    def __init__(self, n=1):
        self.values = [0 for i in range(n)]
        
    def init(self):
        for i in range(len(self.values)):
            self.values[i] = 0

    def update(self, lst):
        for i, item in enumerate(lst):
            self.values[i] = max(self.values[i], item)

    def report(self):
        return f'best performance:{self.values}'