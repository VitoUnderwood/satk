from .feature import Feature

import torch
from torch.utils.data import DataLoader, RandomSampler, TensorDataset


def convert_to_tensor(data, batch_size, shuffle):
    tensors = []
    for item in data:
        # item: (f, f, ...)
        # item: ((int, int, ...), ...)
        # item: (int, int, ...)
        if type(item[0]) is Feature:
            _tensors = convert_feature_to_tensor(item)
            tensors.extend(_tensors)

        else:
            _tensor = torch.tensor(item, dtype=torch.long)
            tensors.append(_tensor)

    dataset = TensorDataset(*tensors)
    sampler = RandomSampler(dataset) if shuffle else None
    dataloader = DataLoader(dataset, sampler=sampler, batch_size=batch_size)

    return dataloader


def convert_feature_to_tensor(features):
    all_idx = torch.tensor([f.idx for f in features], dtype=torch.long)
    all_input_ids = torch.tensor([f.input_ids for f in features], dtype=torch.long)
    all_input_mask = torch.tensor([f.input_mask for f in features], dtype=torch.long)
    all_segment_ids = torch.tensor([f.segment_ids for f in features], dtype=torch.long)
    return all_idx, all_input_ids, all_input_mask, all_segment_ids


def make_dataloader(task, *args, **kwargs):
    if task in ('asc', 'bert-pair', 'bert-segment', 'asco'):
        return _make_dataloader_asco(task, *args, **kwargs)

    elif task == 'post_train':
        return _make_dataloader_post_train(*args, **kwargs)

    elif task == 'towe':
        return _make_dataloader_towe(*args, **kwargs)

    elif task == 'towe-span':
        return _make_dataloader_towe_span(*args, **kwargs)

    elif task == 'aste':
        return _make_dataloader_aste(*args, **kwargs)

    elif task in ('target-crf', 'opinion-crf'):
        return _make_dataloader_ote_crf(task, *args, **kwargs)

    elif task == 'opinion-span':
        return _make_dataloader_ote_span(*args, **kwargs)

    else :
        raise NotImplementedError()


def _make_dataloader_ote_crf(task, examples, tokenizer, batch_size, max_seq_length, shuffle=True):
    F = []
    L = []

    for example in examples:
        fe, la = example.ote_crf_fl(task, max_seq_length, tokenizer)
        F.append(fe)
        L.append(la)

    return convert_to_tensor((F, L), batch_size, shuffle=shuffle)


def _make_dataloader_asco(task, examples, tokenizer, batch_size, max_seq_length, shuffle=True):
    F = []
    L1 = []
    L2 = []
    L3 = []

    opinion_num = 0

    for example in examples:
        for fe, la1, la2, la3 in example.asco_opinion_fl(max_seq_length, tokenizer, task=task):
            opinion_num += len(example.opinion)
            F.append(fe)
            L1.append(la1)
            L2.append(la2)
            L3.append(la3)

    print(f'opinion_num: {opinion_num}')
    return convert_to_tensor((F, L1, L2, L3), batch_size, shuffle=shuffle)


def _make_dataloader_towe(examples, tokenizer, batch_size, max_seq_length, shuffle=True):
    F = []
    L = []

    for example in examples:
        fe, la = example.towe_fl(max_seq_length, tokenizer)
        F.append(fe)
        L.append(la)

    return convert_to_tensor((F, L), batch_size, shuffle=shuffle)


def _make_dataloader_towe_span(examples, tokenizer, batch_size, max_seq_length, shuffle=True):
    F = []
    S = []
    E = []
    N = []

    from collections import defaultdict

    opinion_num = defaultdict(int)
    
    for example in examples:
        fe, st, en, nu = example.towe_span_fl(max_seq_length, tokenizer)
        F.append(fe)
        S.append(st)
        E.append(en)
        N.append(nu)
        opinion_num[nu] += 1

    print(opinion_num)

    return convert_to_tensor((F, S, E, N), batch_size, shuffle=shuffle)


def _make_dataloader_aste(examples, tokenizer, batch_size, max_seq_length, shuffle=True):
    FE = [] # [B, L]
    TS = [] # [B, L]
    TE = [] # [B, L]
    TP = [] # [B, L]
    TN = [] # [B, ]
    OS = [] # [B, L]
    OE = [] # [B, L]
    OP = [] # [B, L]
    ON = [] # [B, ]
    TOS = [] # [B, L, L]
    TOE = [] # [B, L, L]
    TON = [] # [B, L]

    # feature, TS, TE, TP, TN, OS, OE, OP, ON, TOS, TOE, TON

    for example in examples:
        fe, ts, te, tp, tn, os, oe, op, on, tos, toe, ton = example.aste_span_fl(max_seq_length, tokenizer)
        FE.append(fe)
        TS.append(ts)
        TE.append(te)
        TP.append(tp)
        TN.append(tn)
        OS.append(os)
        OE.append(oe)
        OP.append(op)
        ON.append(on)
        TOS.append(tos)
        TOE.append(toe)
        TON.append(ton)

    return convert_to_tensor((FE, TS, TE, TP, TN, OS, OE, OP, ON, TOS, TOE, TON), batch_size, shuffle=shuffle)


def _make_dataloader_post_train(examples, tokenizer, batch_size, max_seq_length, shuffle=True):
    F = []
    L = []

    for example in examples:
        for fe, la1, la2, la3 in example.asco_opinion_fl(max_seq_length, tokenizer, task='asc'):
            F.append(fe)
            L.append(la2)

    return convert_to_tensor((F, L), batch_size, shuffle=shuffle)
