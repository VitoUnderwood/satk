from utils import _load_json
from .example import Example


def load_data(file_name):
    examples = []
    for json_obj in _load_json(file_name):
        example = Example.load_from_json(json_obj)
        examples.append(example)
    return examples


def load_data_aste(file_name):
    examples = []
    for json_obj in _load_json(file_name):
        example = Example.load_from_json_aste(json_obj)
        examples.append(example)
    return examples
    