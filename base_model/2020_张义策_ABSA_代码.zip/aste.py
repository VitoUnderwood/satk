from utils import get_device

from specific import BestPerformance
from specific.base_trainer import BaseTrainer
from specific.recorder import AsteRecorder

import argparse
import torch
import math
# from tqdm import tqdm

from transformers.optimization import AdamW
import logging; logging.getLogger("transformers").setLevel(logging.WARNING)


class Trainer(BaseTrainer):
    def __init__(self, model, device, print_step,
                 output_model_dir, fp16):

        super(Trainer, self).__init__(model, device, print_step, output_model_dir, fp16)
        
        self.train_record = AsteRecorder()
        self.valid_record = AsteRecorder()
        self.best_performance = BestPerformance()

    def clip_batch(self, input_ids, additional_inf=(), pad_idx=0):
        input_ids, max_seq_length, input_dim = self._clip_input_ids(input_ids, pad_idx)

        result = (input_ids, )

        for i in range(len(additional_inf)):
            if additional_inf[i].dim() == 1:
                result += (additional_inf[i], )
            if additional_inf[i].dim() == 2:
                result += (additional_inf[i][..., :max_seq_length],)
            elif additional_inf[i].dim() == 3:
                result += (additional_inf[i][..., :max_seq_length, :max_seq_length],)

        return result

    def _prepare_batch(self, batch):
        # feature, TS, TE, TP, TN, OS, OE, OP, ON, TOS, TOE, TON

        idx, input_ids, attention_mask, token_type_ids, ts, te, tp, tn, os, oe, op, on, tos, toe, ton = batch
        batch = self.clip_batch(input_ids,
                                additional_inf=(
                                    attention_mask, token_type_ids,
                                    ts, te, tp, tn, os, oe, op, on, tos, toe, ton), 
                                pad_idx=0)

        batch = tuple(t.to(self.device) for t in batch)
        
        return idx, batch

    def _forward(self, batch, record, p=0):
        # total_loss, t_start_logits, t_end_logits, t_pn,
        # o_start_logits, o_end_logits, o_pn

        idx, batch= self._prepare_batch(batch)
        loss, ts, te, tp, tn, os, oe, op, on, tos, toe, ton = self.model(*batch[:])
        with torch.no_grad():
            record.inc(loss, ts, te, tp, tn, os, oe, op, on, tos, toe, ton, *batch[-11:])

        return loss

    def _report(self, train_record, valid_record):
        tloss, t_tf1 = train_record.report()
        vloss, v_tf1 = valid_record.report()

        print(f'\n____Train: loss {tloss:.4f}, f1: {t_tf1:.4f}|'
              f' Test: loss {vloss:.4f} f1: {v_tf1:.4f}')

        return v_tf1

    def make_optimizer(self, weight_decay, lr):
        params = list(self.model.named_parameters())

        keywords = []

        def has_keywords(n):
            return any(nd in n for nd in keywords)

        parameters = [
            {'params': [p for n, p in params if has_keywords(n)], 'lr': lr},
            {'params': [p for n, p in params if not has_keywords(n)], 'lr': lr}
        ]

        optimizer = AdamW(parameters, eps=1e-8)
        return optimizer


class ASTE:
    """
    1. self.init()
    2. self.train(...)
    3. cls.load(...)
    """
    def __init__(self, config):
        self.config = config

    def init(self, ModelClass):
        gpu_ids = list(map(int, self.config.gpu_ids.split()))
        device = get_device(gpu_ids)

        print('init_model', self.config.bert_model_dir)

        model = ModelClass.from_pretrained(self.config.bert_model_dir)

        self.trainer = Trainer(
            model, device,
            self.config.print_step,
            self.config.output_model_dir,
            self.config.fp16)

    def train(self, train_dataloader, test_dataloader):
        self.trainer.set_t_total(train_dataloader, self.config.num_train_epochs)
        warmup_proportion = self.config.warmup_proportion

        self.trainer.set_optimizer_and_scheduler(self.config.weight_decay, self.config.lr, warmup_proportion)

        self.trainer.train(self.config.num_train_epochs, train_dataloader, test_dataloader)

    @classmethod
    def load(cls, config, ModelClass):

        srt = cls(config)
        srt.trainer = Trainer.load_model(ModelClass, config)

        return srt


def get_args():
    parser = argparse.ArgumentParser()

    # 训练过程中的参数
    parser.add_argument('--lr', type=float, default=3e-5)
    parser.add_argument('--batch_size', type=int, default=16)
    parser.add_argument('--num_train_epochs', type=int, default=5)
    parser.add_argument('--warmup_proportion', type=float, default=0.1)
    parser.add_argument('--weight_decay', type=float, default=0.)

    # 路径参数
    parser.add_argument('--train_file_name', type=str)
    parser.add_argument('--test_file_name', type=str)

    parser.add_argument('--output_model_dir', type=str)
    parser.add_argument('--bert_model_dir', type=str)
    parser.add_argument('--bert_vocab_dir', type=str)

    # 其他参数
    parser.add_argument('--print_step', type=int, default=100)
    parser.add_argument('--gpu_ids', type=str, default='0', help='以空格分割')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--mission', type=str, default='train')
    parser.add_argument('--max_seq_length', type=int, default=128)
    parser.add_argument('--fp16', action='store_true')
    # parser.add_argument('--model_type', type=str, default='asc')

    args = parser.parse_args()
    return args


if __name__ == '__main__':
    from transformers.tokenization_bert import BertTokenizer as Tokenizer

    from specific.io import load_data_aste
    from specific.tensor import make_dataloader
    from model.aste_span_model import AsteModel
    from utils import set_seed

    args = get_args()
    assert args.mission in ('train', 'output', 'analysis')
    # assert args.model_type in ('crf', 'span', 'gate-crf', 'gate-span')

    # 设置随机种子，保证模型的可复现性
    set_seed(args)

    # ------------------------------------------------#
    print('load_data', args.train_file_name)
    train_data = load_data_aste(args.train_file_name)

    print('load_data', args.test_file_name)
    test_data = load_data_aste(args.test_file_name)

    print('load_vocab', args.bert_vocab_dir)
    tokenizer = Tokenizer.from_pretrained(args.bert_vocab_dir)

    dataloader_task = 'aste'

    test_dataloader = make_dataloader(
        dataloader_task, test_data, tokenizer,
        batch_size=args.batch_size,
        max_seq_length=args.max_seq_length,
        shuffle=False)

    print('test_data %d ' % len(test_data))

    train_dataloader = make_dataloader(
        dataloader_task, train_data, tokenizer,
        batch_size=args.batch_size,
        max_seq_length=args.max_seq_length)

    print('train_data %d ' % len(train_data))

    # -------------------- main ----------------------#
    if args.mission == 'train':
        srt = ASTE(args)
        srt.init(AsteModel)
        srt.train(train_dataloader, test_dataloader)

    elif args.mission in ('output', 'analysis'):
        raise NotImplementedError()
    # ------------------------------------------------#
